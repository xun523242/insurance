﻿lbl_PageName = カレンダー一覧
btn_Refresh = リフレッシュ
btn_BatchAdd = 一括新規
btn_DefaultAdd = デフォルト新規
lbl_Undo = 未対応
lbl_Doing = 対応中
lbl_Done = 対応済