﻿lbl_PageName = ファイルアップロード
lbl_file = ファイル
btn_upload = アップロード
btn_select = 参照
lbl_FileCondition = ファイル情報
