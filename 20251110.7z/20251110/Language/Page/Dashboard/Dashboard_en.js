﻿lbl_TitleInfo = AI無人監視ダッシュボード
lbl_AllInfo = 全体案件進捗率
lbl_GMS = SUMIRE
lbl_OnPre = 別システム
lbl_DataDog = 別システム
lbl_NOC = 別システム