﻿lbl_PageName_AutoSendMail = 自動送信
lbl_AutoSendMail = 送信
lbl_From = 差出人
lbl_To = 宛先
lbl_CC = CC
lbl_BCC = BCC
lbl_MailName = 件名
lbl_MailContent = メール本文
lbl_AddFile = 添付ファイル

btn_Send = 送信
btn_Sended = 送信済
btn_Back = 戻る
btn_FirstSend = 送信済
btn_RecoveredSend = 復旧済
btn_CyberArkEPMSend = 送信済
btn_select = 参照