﻿lbl_TitleInfo = SL無人監視ダッシュボード
lbl_AllInfo = 全体案件進捗率
lbl_Batch = Batch
lbl_Prod = Prod
lbl_Notification = AWS Notification
lbl_CloudWatch = AWS CloudWatch