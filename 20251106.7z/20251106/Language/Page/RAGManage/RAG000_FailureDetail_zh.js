﻿lbl_BusinessType = 業務種別
lbl_MailAddr = メールアドレス
lbl_PhoneNumber = 電話番号
lbl_FailureInfo = 処理失敗明細情報
lbl_CreateBy = 新規者
lbl_CreateTime = 新規時間
lbl_UpdateBy = 更新者
lbl_UpdateTime = 更新日時

btn_Save = 保存
btn_Back = 戻る
lbl_PageName = 処理失敗詳細