﻿// 英文
var EN = "001";
// 日文
var JP = "002";
// 中文
var CN = "003";

// 日期控件格式
var dateformat = "yyyy/mm/dd";
// 时间控件格式
var datetimeformat = "yyyy/mm/dd hh:mm:ss";

//検索条件
var SearchCondition = "SearchCondition";
var gridDefaultHight = 140;
//系统语言
var SystemLanguage = getlang();
//select2控件使用标识
var select2Flag = true;

////******************************************************************************
//// 功能     : 全局捕获JS异常
//// 戻る值   : 拼接后的控件值
//// 参数     ：无
////******************************************************************************
//window.onerror = function (msg, url, l) {
//    debugger
//    var txt = "There was an error on this page.\n\n"
//    txt += "Error: " + msg + "\n"
//    txt += "URL: " + url + "\n"
//    txt += "Line: " + l + "\n\n"
//    txt += "Click OK to continue.\n\n"
//    alert(txt);
//    return true
//}

//******************************************************************************
// 功能     : 获取当前系统时间
// 戻る值   : 当前系统时间
// 参数     ：无
//******************************************************************************
function getCurrentTime() {
    return new Date();
}

//******************************************************************************
// 功能     : 获取ユーザ登录情報
// 戻る值   : 拼接后的控件值
// 参数     ：无
//******************************************************************************
function getUserLoginInfo() {
    return getWebControls("LoginInfoDiv", "top");
}

//******************************************************************************
// 功能     : 获取元素下的所有控件值
// 戻る值   : 拼接后的控件值
// 参数     ：element - 画面对象
// 参数     ：owner - self：本画面;top：顶层画面
//******************************************************************************
function getWebControls(element, owner) {
    var reVal = "";
    var item = {};
    var obj;
    if (owner == "top") {
        obj = top.$("#" + element).find('input,select,textarea');
    }
    else {
        obj = $("#" + element).find('input,select,textarea');
    }
    obj.each(function (r) {
        var id = $(this).attr('id');
        //排除掉ID为空的,排除掉ID中有➩的,排除掉ID以jqg_开头的,排除掉ID以cb_开头的
        if (!isNullOrEmpty(id) && id.indexOf("➩") == -1 && id.indexOf("jqg_") != 0 && id.indexOf("cb_") != 0) {
            var value = $(this).val();
            var type = $(this).attr('type');
            if (id == "WatchType" || id == "ChargeBy") {
                if (value[0] == "") {
                    item[id] = value.toString().substring(1);
                } else {
                    item[id] = value.toString();
                }
                return true;
            }
            switch (type) {
                case "checkbox":
                    if (this.checked) {
                        item[id] = true;
                    } else {
                        item[id] = false;
                    }
                    break;
                case "button":
                    break;
                default:
                    item[id] = value;
                    break;
            }
        }
    });
    reVal = JSON.stringify(item);
    return reVal;
}

//******************************************************************************
// 功能     : 自动给控件赋值
// 戻る值   : 无
// 参数     ：data - 数据源
//******************************************************************************
function setWebControls(data) {
    for (var key in data) {
        var obj = $('#' + key);
        var value = data[key];
        var type = obj.attr('type');
        switch (type) {
            case "checkbox":
                if (value == 1) {
                    obj.attr("checked", 'checked');
                } else {
                    obj.removeAttr("checked");
                }
                break;
            default:
                obj.val(value);
                //如果使用select2控件，需要更新select2的值
                if (select2Flag && obj.is("select")) {
                    if ("ChargeBy" === key && value != null && value.indexOf(',') != -1) {
                        $('#ChargeBy').val(value.split(',')).trigger('change')
                    } else {
                        obj.val(value).trigger("change");
                    }
                }
                break;
        }
    }
}

//******************************************************************************
// 功能     : postAjax请求(同步)
// 戻る值   : 无
// 参数     ：url - 请求路径
// 参数     ：params - 请求参数
// 参数     ：callback - 回调函数
// 参数     ：async - 默认同步
//******************************************************************************
function postAjaxJson(url, params, callback, asyncFlg) {
    window.setTimeout(function () {
        //请求参数中追加ユーザ情報
        if (params != null) {
            params.userLoginInfo = getUserLoginInfo();
        }
        else {
            params = {
                userLoginInfo: getUserLoginInfo()
            };
        }
        params = JSON.stringify(params);

        $.ajax({
            url: url,
            type: "post",
            data: params,
            dataType: "json",
            contentType: "application/json",
            cache: false,
            async: asyncFlg == true ? false : true,
            success: function (data) {
                callback(data);
                history.replaceState(null, null, 'http://localhost:8084/Home')
                document.title = 'SDシステム'
                //loading(false);
            },
            error: function (xmlReq, err, c) {
                loading(false);
                // 服务器异常时，显示错误情報
                showServerError(xmlReq, err, c);
            }
        });

    }, 200);
}

//******************************************************************************
// 功能     : postAjax请求(同步)
// 戻る值   : 无
// 参数     ：url - 请求路径
// 参数     ：params - 请求参数
// 参数     ：callback - 回调函数
// 参数     ：async - 默认同步
//******************************************************************************
function postAjaxUploadFileJson(url, params, callback) {
    window.setTimeout(function () {
        $.ajax({
            url: url,
            type: "post",
            data: params,
            dataType: "json",
            contentType: false,
            cache: false,
            async: true,
            processData: false,
            success: function (data) {
                callback(data);
                //loading(false);
            },
            error: function (xmlReq, err, c) {
                loading(false);
                // 服务器异常时，显示错误情報
                showServerError(xmlReq, err, c);
            }
        });

    }, 200);
}


//******************************************************************************
// 功能     : 验证是否为空
// 戻る值   : true代表为空,false代表不为空
// 参数     ：str - 需判断的数据
//******************************************************************************
function isNullOrEmpty(str) {
    var isOK = false;
    if (str == undefined || str == "" || str == null) {
        isOK = true;
    }
    return isOK;
}

//******************************************************************************
// 功能     : 显示错误消息
// 戻る值   : 无
// 参数     ：config(msg:错误消息 focusCtrlId:吸附控件  callback:回调函数)
//******************************************************************************
function showErrorMsg(config) {
    if (!config.focusCtrlId) {
        layer.msg("<span style='color:red;font-size:12pt'>" + config.msg + "</span>", { icon: 2, time: 3000 }, function () {
            if (config.callback) {
                config.callback();
            }
        });
    }
    else {
        var ctrl = $("#" + config.focusCtrlId);
        //如果使用select2控件,并且当前控件时下拉框
        if (select2Flag && ctrl.is("select")) {
            layer.tips("<span style='font-size:12pt'>" + config.msg + "</span>", "#select2-" + config.focusCtrlId, {
                tips: [3, "red"]
            });
            //设置控件焦点
            $("#select2-" + config.focusCtrlId).focus();
        }
        else {
            layer.tips("<span style='font-size:12pt'>" + config.msg + "</span>", '#' + config.focusCtrlId, {
                tips: [3, "red"]
            });
            //设置控件焦点
            $("#" + config.focusCtrlId).focus();
        }
    }
    //进度条加载完毕
    loading(false);
}

//******************************************************************************
// 功能     : 显示成功消息
// 戻る值   : 无
// 参数     ：config(msg:成功消息 callback:回调函数)
//******************************************************************************
function showSucessMsg(config) {
    layer.msg("<span style='color:darkgreen;font-size:large'>" + config.msg + "</span>",
        { icon: 1, time: 3000 }, function () {
            if (config.callback) {
                config.callback();
            }
        });
    //进度条加载完毕
    loading(false);
}

//******************************************************************************
// 功能     : 记录错误消息
// 戻る值   : 无
// 参数     ：msg:错误消息 ctrlId:控件ID
//******************************************************************************
function logErrorInfo(msg, ctrlId) {
    var ctrl = $("#" + ctrlId);
    if (select2Flag && ctrl && ctrl.is("select")) {
        ctrl = $("#select2-" + ctrlId);
        //控件追加式样
        $("#select2-" + ctrlId + "-combobox").addClass("field-error");
    }
    else {
        //控件追加式样
        ctrl.addClass("field-error");
    }
    //计算显示图片的相对位置
    var left = ctrl.position().left + ctrl.outerWidth(true) - 19;
    var top = ctrl.position().top + ctrl.outerHeight(true) / 2 - 12;
    ctrl.parent().append('<div id="field-error_' + ctrlId + '" class="field-error-info" style="left:' + left + 'px;top:' + top + 'px;z-index:99999" title="' + msg + '"><i class="fa fa-info-circle" style="background:#fff;"></i></div>');
    $("#field-error_" + ctrlId).click(function () {
        showErrorMsg({
            msg: $(this).attr("title"),
            focusCtrlId: $(this).attr("id").replace("field-error_", ""),
        });
    });
}

//******************************************************************************
// 功能     : Resize错误情報的位置
// 戻る值   : 无
// 参数     ：无
//******************************************************************************
function resizeErrorInfo() {
    var errorInfos = $("body").find(".field-error");
    if (errorInfos.length > 0) {
        $.each(errorInfos, function (i) {
            var ctrl = $(errorInfos[i]);
            if (ctrl[0].className && ctrl[0].className.indexOf("select2") > -1) {
                ctrl = $("#" + ctrl.attr('id').replace("-combobox", ""));
            }
            //计算显示图片的相对位置
            var left = ctrl.position().left + ctrl.outerWidth(true) - 19;
            var top = ctrl.position().top + ctrl.outerHeight(true) / 2 - 12;

            $(ctrl.parent().find(".field-error-info")[0]).css("left", left);
            $(ctrl.parent().find(".field-error-info")[0]).css("top", top);
        });
    }
}

//******************************************************************************
// 功能     : 清空画面上的错误显示
// 戻る值   : 无
// 参数     ：无
//******************************************************************************
function clearAllErrorInfo() {
    //移除错误消息的相关式样
    $("body").find(".field-error-info").unbind("click").remove();
    $("body").find(".field-error").removeClass("field-error");
}

//******************************************************************************
// 功能     : 初期化画面
// 戻る值   : 无
// 参数     ：fileName - 资源文件名称
// 参数     ：commonVersion - 共通版本
//******************************************************************************
function inialPageResource(fileName, commonVersion, buttonRight) {
    //初期化权限
    $("[needRight=yes]").each(function (a, b) {
        if (b.type == "submit") {
            if (buttonRight.indexOf("," + b.id + ",") != -1) {
                $(b).show();
            }
            else {
                $(b).remove();
            }
        }
    });

    //画面Resize
    window.onresize = function () {
        resizeErrorInfo();
    }
    //屏蔽右键
    document.oncontextmenu = function (e) {
        return false;
    };
    //禁止后退键 作用于IE、Chrome 
    document.onkeydown = function (e) {
        //处理键盘事件 禁止后退键（Backspace）密码或单行、多行文本框除外 
        var ev = e || window.event;//获取event对象 
        if (ev.keyCode == 8) {
            var obj = ev.target || ev.srcElement;//获取事件源 
            var t = obj.type || obj.getAttribute('type');//获取事件源类型 
            //获取作为判断条件的事件类型 
            var vReadOnly = obj.getAttribute('readonly');
            var vEnabled = obj.getAttribute('enabled');
            //处理null值情况 
            vReadOnly = (vReadOnly == null) ? false : true;
            vEnabled = (vEnabled == null) ? true : true;

            //当敲Backspace键时，事件源类型为密码或单行、多行文本的， 
            //并且readonly属性为true或enabled属性为false的，则退格键失效 
            var flag1 = ((t == "password" || t == "text" || t == "textarea") && (vReadOnly == true || vEnabled != true)) ? true : false;
            //当敲Backspace键时，事件源类型非密码或单行、多行文本的，则退格键失效 
            var flag2 = (t != "password" && t != "text" && t != "textarea" && t != "search") ? true : false;
            //判断 
            if (flag2) {
                return false;
            }
            if (flag1) {
                return false;
            }
        }
        //如果是ESC
        else if (ev.keyCode == 27) {
            var errorCtrls = $("body").find(".field-error");
            if (errorCtrls.length > 0) {
                //获取当前焦点控件
                var focusCtrls = $(":focus");
                var focusCtrlId = "";
                if (focusCtrls.length > 0) {
                    //获取当前焦点控件是否有样式field-error
                    if ($(focusCtrls[0]).hasClass('field-error')) {
                        focusCtrlId = focusCtrls[0].id;
                    }
                }
                var nextFocusCtrlID = "";
                //如果不为空,定位当前焦点控件的下一个错误控件
                if (!isNullOrEmpty(focusCtrlId)) {
                    for (var i = 0; i < errorCtrls.length; i++) {
                        //循环到当前焦点控件时
                        if (errorCtrls[i].id == focusCtrlId) {
                            if (i == errorCtrls.length - 1) {
                                //如果为最后一个控件，则戻る定位第一个错误控件
                                nextFocusCtrlID = errorCtrls[0].id;
                            }
                            else {
                                //否则定位下一个错误控件
                                nextFocusCtrlID = errorCtrls[i + 1].id;
                            }
                            break;
                        }
                    }
                }
                else {
                    //定位第一个错误控件
                    nextFocusCtrlID = errorCtrls[0].id;
                }
                $("#" + nextFocusCtrlID).focus();
                var errMsg;
                if (nextFocusCtrlID.indexOf('select2') > -1) {
                    errMsg = $("#" + nextFocusCtrlID.replace("-combobox", "")).parent().find(".field-error-info")[0].title;
                }
                else {
                    errMsg = $("#" + nextFocusCtrlID).parent().find(".field-error-info")[0].title;
                }
                showErrorMsg({
                    msg: errMsg,
                    focusCtrlId: nextFocusCtrlID,
                });
            }
        }
        //如果是F2
        else if (ev.keyCode == 113) {
            var tempStr = "";
            //显示该画面需要国际化的标签
            $("[mutiLanuage=yes]").each(function (a, b) {
                tempStr = tempStr + b.id + ' = ' + b.id + '\r\n';
            });
            showTextBoxDialog({
                content: tempStr,
            });
        }
    };
    document.onclick = function (event) {
        //如果Tab菜单打开时
        if (top.$("#tabsList").css("display") != "none") {
            //如果点击div的其他地方,隐藏打开的菜单  
            top.$("#tabsList").hide();
        }
    };

    //画面内容国际化
    pageResourceInternationalization(fileName, commonVersion)

    $.extend($.jgrid.defaults, {
        loadError: function (xhr, status, error) {
            loading(false);
            // 服务器异常时，显示错误情報
            showServerError(xhr, status, error);
        }
    });
}

//******************************************************************************
// 功能     : 画面内容国际化
// 戻る值   : 
// 参数     ：fileName -- 文件名称(含路径)
// 参数     ：commonVersion -- 共通版本
//******************************************************************************
function pageResourceInternationalization(fileName, commonVersion) {
    jQuery.i18n.properties({
        name: fileName + "_" + SystemLanguage,
        path: "/Language/Page/",
        mode: 'map',
        language: SystemLanguage,
        cache: true,
        version: commonVersion,
        callback: function () {
            $("[mutiLanuage=yes]").each(function (a, b) {
                if (b.type != undefined && b.type.toLowerCase() == "hidden") {
                    $(b).val($.i18n.prop(b.id));
                }
                else {
                    $(b).html($.i18n.prop(b.id));
                }
            });
        }
    });
}

//******************************************************************************
// 功能     : 根据消息ID获取消息内容
// 戻る值   : 消息内容
// 参数     ：code -- 消息ID
//******************************************************************************
function getSystemMessage(code) {
    var message = getMessageResource(code);
    for (var j = 1; j < arguments.length; j++) {
        var s = getOtherResource(arguments[j]);
        message = message.replace(new RegExp("\\{" + (j - 1) + "\\}", "g"), s);
    }
    return "[" + code + "]" + message;
}

function getSystemMsgWithoutCode(code) {
    var message = getMessageResource(code);
    for (var j = 1; j < arguments.length; j++) {
        var s = getOtherResource(arguments[j]);
        message = message.replace(new RegExp("\\{" + (j - 1) + "\\}", "g"), s);
    }
    return message;
}

function getFullMessage(msgId, params) {
    var message = getMessageResource(msgId);

    //如果有参数
    if (!params) {
        for (var j = 1; j < params.length; j++) {
            var s = getOtherResource(arguments[j]);
            message = message.replace(new RegExp("\\{" + (j - 1) + "\\}", "g"), s);
        }
    }
    return "[" + code + "]" + message;
}

//******************************************************************************
// 功能     : 根据ID获取对应资源文件内容
// 戻る值   : 资源文件内容
// 参数     ：code -- 资源ID
//******************************************************************************
function getMessageResource(code) {
    var retValue;
    var fdStart = code.indexOf("➩");
    if (fdStart == 0) {
        retValue = code.split("➩")[1];
    }
    else if (fdStart == -1) {
        retValue = eval("SystemMsg_" + SystemLanguage)[code];
        if (retValue == undefined) {
            retValue = code;
        }
    }
    return retValue;
}

//******************************************************************************
// 功能     : 根据ID获取对应其他资源文件内容
// 戻る值   : 资源文件内容
// 参数     ：code -- 资源ID
//******************************************************************************
function getOtherResource(code) {
    var retValue;
    var fdStart = code.indexOf("➩");
    if (fdStart == 0) {
        retValue = code.split("➩")[1];
    }
    else if (fdStart == -1) {
        retValue = eval("OtherResource_" + SystemLanguage)[code];
        if (retValue == undefined) {
            retValue = code;
        }
    }
    return retValue;
}

//******************************************************************************
// 功能     : 获取系统的语言
// 戻る值   : 无
// 参数     ：无
//******************************************************************************
function getlang() {
    var language = $("#Language", top.document).val();
    var lang;
    if (language == EN) {
        lang = "en";
    } else if (language == CN) {
        lang = "zh";
    } else {
        lang = "jp";
    }
    return lang;
}

//******************************************************************************
// 功能     : 设置系统的语言
// 戻る值   : 无
// 参数     ：无
//******************************************************************************
function setlang() {
    var language = $("#Language", parent.document).val();
    var lang;
    if (language == EN) {
        lang = "en";
    } else if (language == CN) {
        lang = "zh";
    } else {
        lang = "jp";
    }
    SystemLanguage = lang;
}

//******************************************************************************
// 功能     : 弹出对话框
// 戻る值   : 无
// 参数     ：config(url-画面Url; paramMap-get请求参数; width-宽度; height-高度)
//******************************************************************************
function openDialog(config) {
    //关闭进度条
    loading(false);

    if (!config.paramMap) {
        config.paramMap = new Map();
    }
    //追加ユーザ情報
    config.paramMap.set("userLoginInfo", getUserLoginInfo());

    var param = "";
    config.paramMap.forEach(function (value, key) {
        if (isNullOrEmpty(param)) {
            param = key + '=' + encodeURIComponent(value);
        }
        else {
            param = param + "&" + key + '=' + encodeURIComponent(value);
        }
    });

    if (!config.width || config.width == 0) {
        //如果没设定宽度，则为父窗体的80%
        config.width = $(window).width() * 0.8;
    }
    if (!config.height || config.height == 0) {
        //如果没设定高度，则为父窗体的95%
        config.height = $(window).height() * 0.95;
    }
    layer.open({
        type: 2,
        area: [config.width + 'px', config.height + 'px'],
        maxmin: true,
        fixed: false, //不固定
        resize: false,
        moveOut: true,
        title: " ",
        isOutAnim: false,
        moveType: 1,
        anim: -1,
        content: config.url + "?" + param
    });
}

//******************************************************************************
// 功能     : 关闭对话框
// 戻る值   : 无
// 参数     ：无
//******************************************************************************
function closeDialog() {
    //先得到当前iframe层的索引
    var index = parent.layer.getFrameIndex(window.name);
    parent.layer.close(index);
}

//******************************************************************************
// 功能     : 确认对话框
// 戻る值   : 无
// 参数     ：config(msg-消息或者消息ID;callback-回调函数)
//******************************************************************************
function confirmDialog(config) {
    layer.confirm("<span style='color:darkgreen;font-size:12pt'>" + config.msg + "</span>", { icon: 3, title: ' ', moveOut: true, btn: ['確認', '取消'] }, function (index) {
        layer.close(index);
        if (config.callback) {
            config.callback();
        }
    });
    //进度条加载完毕
    loading(false);
}

//******************************************************************************
// 功能     : 警告对话框
// 戻る值   : 无
// 参数     ：config(msg-消息或者消息ID; callback-回调函数)
//******************************************************************************
function alertDialog(config) {
    layer.alert("<span style='color:darkgreen;font-size:12pt'>" + config.msg + "</span>", { icon: 7, title: ' ', moveOut: true, btn: '確認' }, function (index) {
        layer.close(index);
        if (config.callback) {
            config.callback();
        }
    });
    //进度条加载完毕
    loading(false);
}

//******************************************************************************
// 功能     : 显示数据对话框(用TextBox显示)
// 戻る值   : 无
// 参数     ：config(content-内容;width:对话框宽度;height:对话框高度)
//******************************************************************************
function showTextBoxDialog(config) {
    if (!config.width || config.width == 0) {
        //如果没设定宽度，则为父窗体的80%
        config.width = $(window).width() * 0.8;
    }
    if (!config.height || config.height == 0) {
        //如果没设定高度，则为父窗体的80%
        config.height = $(window).height() * 0.75;
    }

    layer.prompt({
        formType: 2,
        id: this.name,
        value: config.content,
        title: ' ',
        moveOut: true,
        isOutAnim: false,
        moveType: 1,
        anim: -1,
        area: [config.width + 'px', config.height + 'px'],
        maxlength: 50000,
        btn: ['確認', '取消']
    }, function (value, index, elem) {
        layer.close(index);
    })
    //进度条加载完毕
    loading(false);
}

//******************************************************************************
// 功能     : 显示异常情報对话框
// 戻る值   : 无
// 参数     ：content-异常情報内容
//******************************************************************************
function showExceptionDialog(content) {
    layer.open({
        type: 0,
        area: [$(window).width() * 0.8 + 'px', $(window).height() * 0.9 + 'px'],
        maxmin: true,
        fixed: false, //不固定
        resize: false,
        moveOut: true,
        title: " ",
        isOutAnim: false,
        moveType: 1,
        anim: -1,
        content: content,
        btn: ['確認', '取消']
    });
    //进度条加载完毕
    loading(false);
}

//******************************************************************************
// 功能     : 加载关闭进度条
// 戻る值   : 无
// 参数     ：bool - 显示关闭进度条标识
//            allMark - true表示不透明遮罩
//******************************************************************************
function loading(bool, allMark) {
    var ajaxbg = top.$("#loading_background,#loading");
    //背景为不透明遮罩
    if (allMark) {
        top.$("#loading_background").css("opacity", "1");
    }
    else {
        top.$("#loading_background").css("opacity", "0");
    }
    top.$("#loading").css("left", (top.$('body').width() - top.$("#loading").width()) / 2);
    top.$("#loading").css("top", (top.$('body').height() - top.$("#loading").height()) / 2);
    if (bool) {
        ajaxbg.show();
    } else {
        ajaxbg.hide();
    }
}

function inform20min(bool) {
    var ajaxbg = top.$("#loading_background,#inform20");
    //背景为不透明遮罩
    top.$("#loading_background").css("opacity", "0");
    top.$("#inform20").css("left", (top.$('body').width() - top.$("#inform20").width()) / 2);
    top.$("#inform20").css("top", (top.$('body').height() - top.$("#inform20").height()) / 2);
    if (bool) {
        ajaxbg.show();
    } else {
        ajaxbg.hide();
    }
}

//******************************************************************************
// 功能     : 绑定下拉框(无空白行)
// 戻る值   : 无
// 参数     ：config(controlId-下拉框ID;data-数据源;defaultVal-默认值;isFirstEmpty-是否有空白行)
//******************************************************************************
function bindDropItem(config) {
    var dropList = $("#" + config.controlId);
    if (!config.notClearFlag) {
        //先清空下拉框
        dropList.empty();
    }
    if (config.isFirstEmpty) {
        //添加空白行
        dropList.append($("<option value=''></option>"));
    }

    //获取画面的操作区分
    var strFlag = $("#strFlag").val();

    if (config.data) {
        $.each(config.data, function (i) {
            var status = config.data[i]["Status"];
            //如果不是作废状態
            if (status != "002") {
                dropList.append($("<option></option>").val(config.data[i]["SelectKey"]).html(config.data[i]["SelectValue"]));
            }
            else {
                //编辑模式
                if (strFlag == "E") {
                    dropList.append($("<option disabled='disabled' style='background-color:rgba(242, 242, 242, 1)'></option>").val(config.data[i]["SelectKey"]).html(config.data[i]["SelectValue"]));
                }
                //不是追加模式
                else if (strFlag != "A") {
                    dropList.append($("<option style='background-color:rgba(242, 242, 242, 1)'></option>").val(config.data[i]["SelectKey"]).html(config.data[i]["SelectValue"]));
                }
            }
        });
    }
    if (!isNullOrEmpty(config.defaultVal)) {
        dropList.val(config.defaultVal);
    }
    if (select2Flag) {
        if (config.searchBox) {
            dropList.select2();
        }
        else {
            dropList.select2({
                minimumResultsForSearch: -1
            });
        }
    }

    //去重处理
    var i = 0;
    while (i < dropList[0].length) {
        var j = i + 1;
        while (j < dropList[0].length) {
            if (dropList[0].options[i].text == dropList[0].options[j].text) {
                dropList[0].options[j] = null;
            } else {
                j++;
            }
        }
        i++;
    }
}

//******************************************************************************
// 功能     : 动态菜单tab标签
// 戻る值   : 无
// 参数     ：tabID-TabID
// 参数     ：url-url地址
// 参数     ：tabName-Tab显示名称
// 参数     ：img-Tab图标名称
// 参数     ：Isclose-是否带关闭按钮
//******************************************************************************
function addTabMenu(tabID, url, tabName, img, Isclose, params) {
    var tabs_container = top.$("#tabs_container");
    var contentPannel = top.$("#contentPannel");
    //如果当前tabID存在直接显示已经打开的tab
    if (top.document.getElementById("tabs_" + tabID) == null) {
        //打开新Tab
        //进度条加载(不透明遮罩)
        loading(true, true);

        if (tabs_container.find('li').length >= 10) {
            loading(false);
            //最多打开10个Tab
            alertDialog({
                msg: getSystemMessage("E9999"),
            });
            return false;
        }
        //移除原先選択的Tab样式        
        tabs_container.find('li').removeClass('selected');
        contentPannel.find('iframe').hide();
        top.$("#ModuleId").val(tabID);
        //判断是否带关闭tab
        if (Isclose != 'false') {
            //带关闭按钮的Tab
            tabs_container.append("<li id=\"tabs_" + tabID + "\" class=\"selected\" win_close='true'><span title='" + tabName + "' onclick=\"addTabMenu('" + tabID + "','" + url + "','" + tabName + "','true')\"><i style=\"margin-right:5px\" class=\"menu-icon " + img + "\"></i>" + tabName + "</span><a class=\"win_close\" title=\"Close\" onclick=\"closeTab('" + tabID + "')\"></a></li>");
        } else {
            //不带关闭按钮的Tab
            tabs_container.append("<li id=\"tabs_" + tabID + "\" class=\"selected\" ><span title='" + tabName + "' onclick=\"addTabMenu('" + tabID + "','" + url + "','" + tabName + "','false')\"><i style=\"margin-right:5px\" class=\"menu-icon " + img + "\"></i>" + tabName + "</span></li>");
            // tabs_container.append("<li id=\"tabs_" + tabID + "\" class=\"selected\" onclick=\"addTabMenu('" + tabID + "','" + url + "','" + tabName + "','false')\"><a><img src='../Content/images/" + img + "'>" + tabName + "</a></li>");
        }
        $("#paramsContent").append('<input type="hidden" id = params_tabs_iframe_' + tabID + '>');

        var iframe_tags = "<iframe id='tabs_iframe_" + tabID + "' name='tabs_iframe_" + tabID + "' height='100%' width='100%' src='" + url;
        var iframe_params = "?userLoginInfo=" + encodeURIComponent(getUserLoginInfo());
        if (params) {
            iframe_params += "&id=" + params
        }
        iframe_tags += iframe_params + "' frameBorder='0'></iframe>";
        contentPannel.append(iframe_tags);
        //添加Tabs列表菜单
        addTabsMenuList(tabID, tabName, img);
        //重新布局Tab
        tabReLayout(tabID);
    }
    else {
        //激活已经打开的Tab
        activeTab(tabID);
    }

    $('iframe#' + getTabiframeId()).load(function () {
        //进度条加载完毕
        //loading(false);
    });
}

//******************************************************************************
// 功能     : 激活Tab
// 戻る值   : 无
// 参数     ：tabid-TabID
//******************************************************************************
function activeTab(tabID) {
    var tabs_container = top.$("#tabs_container");
    var contentPannel = top.$("#contentPannel");
    tabs_container.find('li').removeClass('selected');
    contentPannel.find('iframe').hide();
    var tabObj = tabs_container.find('#tabs_' + tabID);
    if (tabObj.css("display") == 'none') {
        //重新布局Tab
        tabReLayout(tabID);
    }

    tabObj.addClass('selected');
    top.$("#ModuleId").val(tabID);
    top.document.getElementById("tabs_iframe_" + tabID).style.display = 'block';
}

//******************************************************************************
// 功能     : 添加Tabs列表菜单
// 戻る值   : 无
// 参数     ：tabID-TabID
// 参数     ：tabName-Tab显示名称
// 参数     ：img-Tab图标名称
//******************************************************************************
function addTabsMenuList(tabID, tabName, img) {
    var tabsListMenu = top.$("#tabsListMenu");
    tabsListMenu.append("<li id=\"tabsMenu_" + tabID + "\" class=\"hided\" onclick=\"activeTab('" + tabID + "')\" style=\"cursor:pointer\"><i class=\"menu-icon " + img + "\" style=\"margin-right: 5px;margin-left: 5px\"></i>" + tabName + "</li>");
}

//******************************************************************************
// 功能     : 获取动态tab标签当前iframeID
// 戻る值   : iframeID
// 参数     : obj-tabID
//******************************************************************************
function getTabiframeId() {
    var tabs_container = top.$("#tabs_container");
    return "tabs_iframe_" + tabs_container.find('.selected').attr('id').substr(5);
}

//******************************************************************************
// 功能     : 关闭Tab
// 戻る值   : 无
// 参数     : tabID-tabID
//******************************************************************************
function closeTab(tabID) {
    loading(false);
    var tabs_container = top.$("#tabs_container");
    var contentPannel = top.$("#contentPannel");
    var tabsListMenu = top.$("#tabsListMenu");
    //Tab菜单移除
    tabsListMenu.find("#tabsMenu_" + tabID).remove();
    //参数移除
    top.$("#params_tabs_iframe_" + tabID).remove();
    //Tab移除
    tabs_container.find("#tabs_" + tabID).remove();
    //iframe移除
    contentPannel.find("#tabs_iframe_" + tabID).remove();
    var tablist = tabs_container.find('li');
    var pannellist = contentPannel.find('iframe');

    if (tablist.length > 0) {
        tablist.removeClass("selected");
        tablist[tablist.length - 1].className = 'selected';
        pannellist[tablist.length - 1].style.display = 'block';
        var id = tabs_container.find('.selected').attr('id').substr(5);
        top.$("#ModuleId").val(id);
        //重新布局Tab
        tabReLayout(id);
    }
    else {
        //隐藏TabsMenu按钮
        displayTabsMenuButton(false);
    }
}

//******************************************************************************
// 功能     : TabsMenu按钮显示或隐藏
// 戻る值   : 无
// 参数     : bool-true：显示;false：隐藏
//******************************************************************************
function displayTabsMenuButton(bool) {
    var tabsMenuButton = $("#tabsMenuButton", top.document);
    if (bool) {
        tabsMenuButton.show();
    } else {
        tabsMenuButton.hide();
        top.$("#tabsList").hide();
    }
}

//******************************************************************************
// 功能     : Tab菜单的显示控制
// 戻る值   : 无
// 参数     : 无
//******************************************************************************
function displayTabsMenu() {
    var tabsList = $("#tabsList");
    if (tabsList.css("display") == "none") {
        tabsList.show();
    }
    else {
        tabsList.hide();
    }
}

//******************************************************************************
// 功能     : 重新布局Tab
// 戻る值   : 无
// 参数     : tabID-TabID
//******************************************************************************
function tabReLayout(tabID) {
    //Tab容器
    var tabs_container = top.$("#tabs_container");
    var tabsObj = tabs_container.find('li');
    //Tablist菜单
    var tabsListMenu = top.$("#tabsListMenu");
    var tabsListMenuObj = tabsListMenu.find('li');

    //如果tabID为空,则将选中的TabID赋值
    if (isNullOrEmpty(tabID)) {
        //如果找不到选中的Tab,则直接戻る
        if (tabs_container.find('.selected').length == 0) {
            return;
        }
        tabID = tabs_container.find('.selected').attr('id').substr(5);
    }
    var selectIndex = 0;
    var width = 0;
    $(tabsObj).each(function (i) {
        width += $(tabsObj[i]).outerWidth(true);
        if ($(tabsObj[i]).attr('id').substr(5) == tabID) {
            selectIndex = i;
        }
    });

    var containerWidth = tabs_container.outerWidth(true);
    if (width > containerWidth) {
        //长度重置
        width = 0;
        for (var i = selectIndex; i < tabsObj.length; i++) {
            width += $(tabsObj[i]).outerWidth(true);
            if (width <= containerWidth) {
                $(tabsObj[i]).removeClass("hided");
                $(tabsListMenuObj[i]).addClass("hided");
            }
            else {
                $(tabsObj[i]).addClass("hided");
                $(tabsListMenuObj[i]).removeClass("hided");
            }
        }

        for (var i = selectIndex - 1; i >= 0; i--) {
            width += $(tabsObj[i]).outerWidth(true);
            if (width <= containerWidth) {
                $(tabsObj[i]).removeClass("hided");
                $(tabsListMenuObj[i]).addClass("hided");
            }
            else {
                $(tabsObj[i]).addClass("hided");
                $(tabsListMenuObj[i]).removeClass("hided");
            }
        }
        //如果有隐藏Tab,则显示TabsMenu按钮
        if (tabs_container.find('.hided').length > 0) {
            //显示TabsMenu按钮
            displayTabsMenuButton(true);
        }
        else {
            //隐藏TabsMenu按钮
            displayTabsMenuButton(false);
        }
    }
    else {
        tabsObj.removeClass("hided");
        tabsListMenuObj.addClass("hided");
        //隐藏TabsMenu按钮
        displayTabsMenuButton(false);
    }
}

//******************************************************************************
// 功能     : 绘制Datagrid中的操作按钮
// 戻る值   : html样式
//******************************************************************************
function displayButtons(cellvalue, options, rowObject) {
    var edit = "<input type='button' id='edit_" + options.rowId + "' style='text-decoration:underline;border:0;background-color:transparent;color:#307ecc' onclick='edit(" + options.rowId + ");return false;' value='編集'></input>";
    var view = "<input type='button' id='view_" + options.rowId + "' style='text-decoration:underline;border:0;background-color:transparent;color:#307ecc' onclick='view(" + options.rowId + ");return false;' value='照会'></input>";
    return edit + view;
}

function linkButtons(cellvalue, options, rowObject) {
    var linkJira;
    //获取件名
    var title = rowObject.Title;

    if ((new Date(rowObject.ReceivingTime).getTime() > new Date('2024/01/01').getTime() && title.indexOf("19TSCPP") == -1)
        || (title.indexOf("19TSCPP") > -1 && new Date(rowObject.ReceivingTime).getTime() > new Date('2024/01/08 18:00:00').getTime())) {
        linkJira = '対応不要'
    } else {
        if (rowObject.Product == "鍵管理") {
            if (title.indexOf("KMC_21INFRA") > -1 || title.indexOf("19TSCPP") > -1) {
                linkJira = "<input type='button' id='linkJira_" + options.rowId + "' style='text-decoration:underline;border:0;background-color:transparent;color:#307ecc' onclick='linkJira(" + options.rowId + ");return false;' value='JIRA起票'></input>";
            } else {
                linkJira = "<input type='button' id='linkMail_" + options.rowId + "' style='text-decoration:underline;border:0;background-color:transparent;color:#307ecc' onclick='linkMail(" + options.rowId + ");return false;' value='送信'></input>";
            }
        } else if (rowObject.Product == "ログ蓄積基盤" || rowObject.Product == "データ統合管理基盤") {
            linkJira = "<input type='button' id='linkOTA_" + options.rowId + "' style='text-decoration:underline;border:0;background-color:transparent;color:#307ecc' onclick='linkOTA(" + options.rowId + ");return false;' value='Backlog確認'></input>";
        } else if (title.indexOf("17APP") > -1 || title.indexOf("17INFRA") > -1 || title.indexOf("TBDC_19INFRA") > -1 || title.indexOf("TBDC_19APP") > -1 || title.indexOf("ECN_19APP") > -1 || title.indexOf("ECN_19INFRA") > -1) {
            // 17/19
            if (title.indexOf(":OK ") > -1 && title.indexOf(":OK LOG") < 0) {
                linkJira = "<input type='button' id='linkJira_" + options.rowId + "' style='text-decoration:underline;border:0;background-color:transparent;color:#307ecc' onclick='linkJiraUpd(" + options.rowId + ");return false;' value='JIRA更新'></input>";
            } else {
                linkJira = "<input type='button' id='linkJira_" + options.rowId + "' style='text-decoration:underline;border:0;background-color:transparent;color:#307ecc' onclick='linkJira(" + options.rowId + ");return false;' value='JIRA起票'></input>";
            }
        } else {
            linkJira = "<input type='button' id='linkJira_" + options.rowId + "' style='text-decoration:underline;border:0;background-color:transparent;color:#307ecc' onclick='linkJira(" + options.rowId + ");return false;' value='JIRA起票'></input>";
        }
    }
    return linkJira;
}

function linkGmsButtons(cellvalue, options, rowObject) {
    var linkGms;
    if (rowObject.RemarkName == "特別静観" || rowObject.RemarkName == "静観") {
        linkGms = "";
    } else {
        linkGms = "<input type='button' id='linkGms_" + options.rowId + "' style='text-decoration:underline;border:0;background-color:transparent;color:#307ecc' onclick='linkGms(" + options.rowId + ");return false;' value='SNOW起票'></input>";
    }
    return linkGms;
}

function NDHK_confirm(cellvalue, options, rowObject) {
    var res;
    if (rowObject.Channel === '#mon-prod-processor') {
        res = '確認不要'
    } else {
        if (rowObject.SlackConfirm) {
            res = "<input type='checkbox' checked='checked' value='true' offval='no' disabled='disabled' class='active-checkbox'>"
        } else[
            res = "<input type='checkbox' value='false' offval='no' disabled='disabled'"
        ]
    }

    return res;
}

function linkArioHPButtons(cellvalue, options, rowObject) {
    var linkArio;
    if (rowObject.RemarkName == "AWS＋Jira＋Mail") {
        linkArio = "<input type='button' id='linkArio_" + options.rowId + "' style='text-decoration:underline;border:0;background-color:transparent;color:#307ecc' onclick='linkArio(" + options.rowId + ");return false;' value='AWS確認'></input>";
    } else {
        linkArio = "";
    }
    return linkArio;
}

//******************************************************************************
// 功能     : jgrid日期格式化"yyyy/MM/dd hh:mm:ss"
// 戻る值   : 格式化后的时间
//******************************************************************************
function pickDateTime(cellvalue, options, cell) {
    if (cellvalue == null || cellvalue == "") {
        return cellvalue;
    }
    return dateFormat(cellvalue, "yyyy/MM/dd hh:mm:ss");
}

function levelup(cellvalue, options, rowObject) {
    return '<a onclick="levelupPopUp(' + rowObject.AlertId + ');"><i class="fa fa-level-up" style="font-size: 1.5em;"></i></a>';
}

//******************************************************************************
// 功能     : jgrid日期格式化"yyyy/MM/dd hh:mm"
// 戻る值   : 格式化后的时间
//******************************************************************************
function pickDateTimeToMinute(cellvalue, options, cell) {
    if (cellvalue == null || cellvalue == "") {
        return cellvalue;
    }
    return dateFormat(cellvalue, "yyyy/MM/dd hh:mm");
}

//******************************************************************************
// 功能     : 日期格式化
// 戻る值   : 格式化后的时间
// 参数     : str - 时间
// 参数     : fmt - 格式
//******************************************************************************
function dateFormat(str, fmt) {
    var date = new Date();
    if (str) {
        date = new Date(str);
    }
    var o = {
        "M+": date.getMonth() + 1, //月份 
        "d+": date.getDate(), //日 
        "h+": date.getHours(), //小时 
        "m+": date.getMinutes(), //分 
        "s+": date.getSeconds(), //秒 
        "q+": Math.floor((date.getMonth() + 3) / 3), //季度 
        "S": date.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}

//******************************************************************************
// 功能     : 保存页面検索条件
// 戻る值   : 无
// 参数     : paramsValue-検索条件内容
//******************************************************************************
function saveSearchCondition(paramsValue) {
    savePageParams(SearchCondition, paramsValue);
}

//******************************************************************************
// 功能     : 获取页面検索条件内容
// 戻る值   : 戻る页面検索条件内容
// 参数     : 无
//******************************************************************************
function getSearchCondition() {
    return getPageParams(SearchCondition);
}

//******************************************************************************
// 功能     : 保存页面参数
// 戻る值   : 无
// 参数     : paramsID-参数ID,paramsValue-参数内容
//******************************************************************************
function savePageParams(paramsID, paramsValue) {
    var frameId = window.frameElement && window.frameElement.id || '';
    //获取参数
    var paramsContent = $("#params_" + frameId, parent.document).val();
    if (paramsContent.length > 0) {
        var paramsJson = JSON.parse(paramsContent);
        for (var i = 0; i < paramsJson.length; i++) {
            if (paramsJson[i].id == paramsID) {
                paramsJson[i].value = paramsValue;
                $("#params_" + frameId, parent.document).val(JSON.stringify(paramsJson));
                return;
            }
        }
        //现有参数中追加参数
        paramsJson.push({ id: paramsID, value: paramsValue });
        $("#params_" + frameId, parent.document).val(JSON.stringify(paramsJson));
    }
    else {
        //追加参数
        $("#params_" + frameId, parent.document).val("[" + JSON.stringify({ id: paramsID, value: paramsValue }) + "]");
    }
}

//******************************************************************************
// 功能     : 获取页面参数
// 戻る值   : 戻る参数ID对应的参数内容
// 参数     : paramsID-参数ID
//******************************************************************************
function getPageParams(paramsID) {
    var frameId = window.frameElement && window.frameElement.id || '';
    //获取参数
    var paramsContent = $("#params_" + frameId, parent.document).val();
    if (paramsContent.length > 0) {
        var paramsJson = JSON.parse(paramsContent);
        for (var i = 0; i < paramsJson.length; i++) {
            if (paramsJson[i].id == paramsID) {
                return JSON.parse(paramsJson[i].value);
            }
        }
    }
    return null;
}

//******************************************************************************
// 功能     : 服务器异常时，显示错误情報
// 戻る值   : 无
// 参数     ：xhr
// 参数     : status
// 参数     : error
//******************************************************************************
function showServerError(xhr, status, error) {
    alertDialog({
        msg: "Sorry，Something Went Wrong！</br><div id=\"SysExceptionMessage\" style = \"display: none;\">" + encodeURIComponent(xhr.responseText) + "</div>\r\n <a style=\"cursor: pointer\" onclick=\"viewExceptionMessage();\">View Exception Message</a>",
        callback: function () {
            $("#SysExceptionMessage").remove();
        }
    });

    let frameId = getTabiframeId();
    if (frameId && frameId.indexOf("Dashboard_SAI") != -1) {
        setTimeout(function () {
            $('.layui-layer-btn0').click();
        }, 2000)
    }
}

//******************************************************************************
// 功能     : 查看异常情報
// 戻る值   : 无
// 参数     ：无
//******************************************************************************
function viewExceptionMessage() {
    var errorMsg = $("#SysExceptionMessage").html();
    $("#SysExceptionMessage").remove();
    showExceptionDialog(decodeURIComponent(errorMsg), function () { });
}

//******************************************************************************
// 功能     : 画面跳转
// 戻る值   : 无
// 参数     ：url - url地址
// 参数     ：myMap - get参数
//******************************************************************************
function pageRedirect(url, myMap) {
    var param = "";
    if (!myMap) {
        myMap = new Map();
    }
    //追加ユーザ情報
    myMap.set("userLoginInfo", getUserLoginInfo());

    myMap.forEach(function (value, key) {
        if (isNullOrEmpty(param)) {
            param = key + '=' + encodeURIComponent(value);
        }
        else {
            param = param + "&" + key + '=' + encodeURIComponent(value);
        }
    });
    window.location.href = url + "?" + param;
}

//******************************************************************************
// 功能     : 单行選択检查
// 戻る值   : true为单行;false:未選択或者選択多行
// 参数     ：selRowID - 選択行ID
//******************************************************************************
function oneRowSelectCheck(selRowID) {
    if (typeof (selRowID) == "string") {
        if (isNullOrEmpty(selRowID)) {
            return false;
        }
    }
    else if (typeof (selRowID) == "object") {
        if (selRowID == null || selRowID.length != 1) {
            return false;
        }
    }
    return true;
}

//******************************************************************************
// 功能     : 多行選択检查
// 戻る值   : true为多行;false:未選択
// 参数     ：selRowID - 選択行ID
//******************************************************************************
function mutiRowSelectCheck(selRowID) {
    if (typeof (selRowID) == "string") {
        if (isNullOrEmpty(selRowID)) {
            return false;
        }
    }
    else if (typeof (selRowID) == "object") {
        if (selRowID == null || selRowID.length == 0) {
            return false;
        }
    }
    return true;
}

//******************************************************************************
// 功能     : POST传参下载文件
// 戻る值   : 无
// 参数     ：options:选项
// 调用列子：
//           postDownLoadFile({
//               url: "../SPM010_DeliveryNoteList/DoExport",
//               data: {
//                  deliveryNoteNoList: deliveryNoteNoList,
//                  exportColName: $("#exportColName")[0].innerHTML
//               },
//               method: 'post'
//           });
//******************************************************************************
function postDownLoadFile(options) {
    var config = $.extend(true, { method: 'post' }, options);
    var $iframe = $('<iframe id="down-file-iframe" style="display:none"/>');
    var $form = $('<form target="_self" method="' + config.method + '" />');
    $form.attr('action', config.url + "?v=" + Date.parse(new Date()));
    for (var key in config.data) {
        if (key == "postData") {
            $form.append('<input type="hidden" name="' + key + '" value="' + encodeURIComponent(config.data[key]) + '" />');
        }
        else {
            $form.append('<input type="hidden" name="' + key + '" value="' + config.data[key] + '" />');
        }
    }
    $iframe.append($form);
    $(document.body).append($iframe);
    $form[0].submit();
    $iframe.remove();

    window.setTimeout(function () {
        //进度条关闭
        loading(false);
    }, 2000);
}

//******************************************************************************
// 功能     : 设置控件可编辑
// 戻る值   : 无
// 参数     ：controlIDs - 控件ID,用","拼接
//******************************************************************************
function enableControl(controlIDs) {
    var ctrlIDArray = controlIDs.split(",");
    for (var i = 0; i < ctrlIDArray.length; i++) {
        var ctrl = $("#" + ctrlIDArray[i]);
        if (ctrl) {
            ctrl.removeAttr("disabled");
        }
    }
}

//******************************************************************************
// 功能     : 设置容器中的所有控件只读
// 戻る值   : 无
// 参数     ：containerId - 容器ID
//******************************************************************************
function readonlyControlsOfContainer(containerId) {
    $("#" + containerId).find('input,select,textarea').attr("disabled", "disabled");
}

//******************************************************************************
// 功能     : 设置容器中的所有控件可写
// 戻る值   : 无
// 参数     ：containerId - 容器ID
//******************************************************************************
function ActiveControlsOfContainer(containerId) {
    $("#" + containerId).find('input,select,textarea').removeAttr("disabled");
}

//******************************************************************************
// 功能     : 设置控件只读
// 戻る值   : 无
// 参数     ：controlIDs - 控件ID,用","拼接
//******************************************************************************
function readonlyControl(controlIDs) {
    var ctrlIDArray = controlIDs.split(",");
    for (var i = 0; i < ctrlIDArray.length; i++) {
        var ctrl = $("#" + ctrlIDArray[i]);
        if (ctrl && ctrl.selector != "#undefined") {
            ctrl.attr("disabled", "disabled");
        }
    }
}

//******************************************************************************
// 功能     : 设置控件可见
// 戻る值   : 无
// 参数     ：controlIDs - 控件ID,用","拼接
//******************************************************************************
function displayControl(controlIDs) {
    var ctrlIDArray = controlIDs.split(",");
    for (var i = 0; i < ctrlIDArray.length; i++) {
        var ctrl = $("#" + ctrlIDArray[i]);
        if (ctrl) {
            ctrl.show();
        }
    }
}

//******************************************************************************
// 功能     : 设置控件隐藏
// 戻る值   : 无
// 参数     ：controlIDs - 控件ID,用","拼接
//******************************************************************************
function hideControl(controlIDs) {
    var ctrlIDArray = controlIDs.split(",");
    for (var i = 0; i < ctrlIDArray.length; i++) {
        var ctrl = $("#" + ctrlIDArray[i]);
        if (ctrl) {
            ctrl.hide();
        }
    }
}

//******************************************************************************
// 功能     : 获取控件值
// 戻る值   : 控件的Text值
// 参数     ：ctrl - 控件
//******************************************************************************
function getControlValue(ctrl) {
    var ctrlObj = $(ctrl);
    if (ctrlObj) {
        var tagName = ctrlObj.get(0).tagName;
        if (tagName == "LABEL" || tagName == "BUTTON" || /^[H][0-9]*$/.test(tagName) || tagName == "DIV") {
            return ctrlObj.text();
        }
        else {
            return ctrlObj.val();
        }
    }
}

//******************************************************************************
// 功能     : 前台控件验证
// 戻る值   : true:验证通过;false:验证不通过
// 参数     ：controlId - 控件ID
//******************************************************************************
function controlValidate(controlId) {
    var validateResult = true;
    var obj;
    if (controlId == "" || controlId == undefined) {
        obj = $("[validateInfo]");
    }
    else {
        obj = $("#" + controlId).find('[validateInfo]');
    }
    obj.each(function (a, b) {
        if (!inputFormatVerify(b)) {
            validateResult = false;
        }
    });
    //如果有错误,则报错
    if (!validateResult) {
        showErrorMsg({
            msg: getSystemMessage("E9996"),
        });
    }
    return validateResult;
}

//******************************************************************************
// 功能     : 格式检查
// 戻る值   : false:不是整数；true：整数
// 参数     ：obj       校验对象
//******************************************************************************
function inputFormatVerify(obj) {
    var validateTypes = $(obj).attr("validateInfo").split('|');
    for (var i = 0; i < validateTypes.length; i++) {
        //验证格式
        var type = validateTypes[i];
        //需验证的数据值
        var value = obj.value;

        if (type == "required") { // 必须输入
            if (!isRequired(value)) {
                logErrorInfo(getSystemMessage("required"), obj.id);
                return false;
            }
        } else if (type == "mobile") { // 手机号（1开头的11位数字）
            if (!isMobile(value)) {
                logErrorInfo(getSystemMessage("mobile"), obj.id);
                return false;
            }
        } else if (type == "email") { //邮箱地址
            if (!isEmail(value)) {
                logErrorInfo(getSystemMessage("email"), obj.id);
                return false;
            }
        } else if (type == "date") { //日期
            if (!isDate(value)) {
                logErrorInfo(getSystemMessage("date"), obj.id);
                return false;
            }
        } else if (type == "dateiso") { //日期
            if (!isDateISO(value)) {
                logErrorInfo(getSystemMessage("dateiso"), obj.id);
                return false;
            }
        } else if (type == "number") { //数字
            if (!isNumber(value)) {
                logErrorInfo(getSystemMessage("number"), obj.id);
                return false;
            }
        } else if (type.indexOf("decimal(") == 0) { //Decimal(X,X)
            var params = type.replace("decimal(", "").replace(")", "").split(',');
            //整数位
            var intValue = params[0];
            //小数位
            var decValue = params[1];
            if (!isDecimal(value, intValue, decValue)) {
                logErrorInfo(getSystemMessage("decimal", intValue, decValue), obj.id);
                return false;
            }
        } else if (type == "int") { //整数
            if (!isInterger(value)) {
                logErrorInfo(getSystemMessage("int"), obj.id);
                return false;
            }
        } else if (type == "positiveInt") { //正整数
            if (!isPositiveInt(value)) {
                logErrorInfo(getSystemMessage("positiveInt"), obj.id);
                return false;
            }
        } else if (type.indexOf("maxlength(") == 0) { //最大长度
            //最大长度
            var maxValue = type.replace("maxlength(", "").replace(")", "");
            if (!maxLength(value, maxValue)) {
                logErrorInfo(getSystemMessage("maxlength", maxValue), obj.id);
                return false;
            }
        } else if (type.indexOf("minlength(") == 0) { //最小长度
            //最小长度
            var minValue = type.replace("minlength(", "").replace(")", "");
            if (!minLength(value, minValue)) {
                logErrorInfo(getSystemMessage("minlength", minValue), obj.id);
                return false;
            }
        } else if (type.indexOf("rangelength(") == 0) { //长度范围
            var params = type.replace("rangelength(", "").replace(")", "").split(',');
            //最小长度
            var minValue = params[0];
            //最大长度
            var maxValue = params[1];

            if (!rangeLength(value, minValue, maxValue)) {
                logErrorInfo(getSystemMessage("rangelength", minValue, maxValue), obj.id);
                return false;
            }
        } else if (type.indexOf("max(") == 0) { //最大值(不包含)
            //最大值
            var maxValue = type.replace("max(", "").replace(")", "");
            if (!max(value, maxValue)) {
                logErrorInfo(getSystemMessage("max", maxValue), obj.id);
                return false;
            }
        } else if (type.indexOf("min(") == 0) { //最小值(不包含)
            //最小值
            var minValue = type.replace("min(", "").replace(")", "");
            if (!min(value, minValue)) {
                logErrorInfo(getSystemMessage("min", minValue), obj.id);
                return false;
            }
        } else if (type.indexOf("maxequals(") == 0) { //最大值(包含)
            //最大值
            var maxValue = type.replace("maxequals(", "").replace(")", "");
            if (!maxEquals(value, maxValue)) {
                logErrorInfo(getSystemMessage("maxequals", maxValue), obj.id);
                return false;
            }
        } else if (type.indexOf("minequals(") == 0) { //最小值(包含)
            //最小值
            var minValue = type.replace("minequals(", "").replace(")", "");
            if (!minEquals(value, minValue)) {
                logErrorInfo(getSystemMessage("minequals", minValue), obj.id);
                return false;
            }
        }
        else {
            logErrorInfo(getSystemMessage("propertyerror", type), obj.id);
            return false;
        }
    }
    return true;
}

//******************************************************************************
// 功能     : 判断必须输入
// 戻る值   : false:空；true：非空
// 参数     ：val    
//******************************************************************************
function isRequired(val) {
    if (isNullOrEmpty(val)) {
        return false;
    }
    return true;
}

//******************************************************************************
// 功能     : 判断手机输入是否正确
// 戻る值   : false:错误；true：正确
// 参数     ：val    
//******************************************************************************
function isMobile(mobile) {
    // 如果为空
    if (isNullOrEmpty(mobile)) {
        return true;
    }
    // 正则判断 1开头 一共11位
    return /^1\d{10}$/.test(mobile);
}

//******************************************************************************
// 功能     : 判断e-mail输入是否正确
// 戻る值   : false:错误；true：正确
// 参数     ：email  
//******************************************************************************
function isEmail(email) {
    email = email.replace(new RegExp(" ", "g"), "");
    // 如果为空
    if (isNullOrEmpty(email)) {
        return true;
    }
    // 正则判断 
    return /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/.test(email);
}

//******************************************************************************
// 功能     : 判断是否为日期类型
// 戻る值   : false:错误；true：正确
// 参数     ：value:日期  
//******************************************************************************
function isDate(value) {
    // 如果为空
    if (isNullOrEmpty(value)) {
        return true;
    }
    return !/Invalid|NaN/.test(new Date(value).toString());
}

//******************************************************************************
// 功能     : 判断是否为合法的ISO日期类型
// 戻る值   : false:错误；true：正确
// 参数     ：value:日期  
//******************************************************************************
function isDateISO(value) {
    // 如果为空
    if (isNullOrEmpty(value)) {
        return true;
    }
    return /^\d{4}[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])$/.test(value);
}

//******************************************************************************
// 功能     : 判断是否是整数(正零)
// 戻る值   : false:不是整数；true：整数
// 参数     ：value    
//******************************************************************************
function isInterger(value) {
    // 如果为空
    if (isNullOrEmpty(value)) {
        return true;
    }
    return /^-?\d+$/.test(value);
}

//******************************************************************************
// 功能     : 判断是否是正整数(正零)
// 戻る值   : false:不是正整数；true：正整数
// 参数     ：value    
//******************************************************************************
function isPositiveInt(value) {
    // 如果为空
    if (isNullOrEmpty(value)) {
        return true;
    }
    return /^[0-9]*[1-9][0-9]*$/.test(value);
}

//******************************************************************************
// 功能     : 判断是否是数字
// 戻る值   : false:不是整数；true：整数
// 参数     ：value 验证值
//******************************************************************************
function isNumber(value) {
    // 如果为空
    if (isNullOrEmpty(value)) {
        return true;
    }
    return /^(?:-?\d+|-?\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test(value);
}

//******************************************************************************
// 功能     : 字符串最小长度
// 戻る值   : false:不满足；true：满足
// 参数     ：value：验证值 minLength:最小长度    
//******************************************************************************
function minLength(value, minLength) {
    // 如果为空
    if (isNullOrEmpty(value)) {
        return true;
    }
    return value.length >= minLength;
}

//******************************************************************************
// 功能     : 字符串最大长度
// 戻る值   : false:不满足；true：满足
// 参数     ：value：验证值 param:最大长度       
//******************************************************************************
function maxLength(value, maxLength) {
    // 如果为空
    if (isNullOrEmpty(value)) {
        return true;
    }
    return value.length <= maxLength;
}

//******************************************************************************
// 功能     : 字符串最大长度
// 戻る值   : false:不满足；true：满足
// 参数     ：value：验证值 param:最大长度       
//******************************************************************************
function rangeLength(value, minLength, maxLength) {
    // 如果为空
    if (isNullOrEmpty(value)) {
        return true;
    }
    return value.length <= maxLength && value.length >= minLength;
}

//******************************************************************************
// 功能     : Decimal验证
// 戻る值   : true:Decimal格式;false:非Decimal格式
// 参数     ：strDecimal    -- 判断内容
// 参数     ：ige           -- 整数位长度
// 参数     ：dec           -- 小数位长度
//******************************************************************************
function isDecimal(value, ige, dec) {
    // 如果为空
    if (isNullOrEmpty(value)) {
        return true;
    }
    if (ige > 1) {
        ige = ige - 1;
        if (dec == 0) {
            var reg = new RegExp("^-?([1-9]\\d{1," + ige + "}|\\d)$");
            return reg.test(value);
        }
        else {
            var reg = new RegExp("^-?([1-9]\\d{1," + ige + "}|\\d)(\\.\\d{1," + dec + "})?$");
            return reg.test(value);
        }
    }
    else {
        var reg = new RegExp("^-?[0](\\.[0-9]{1," + dec + "})?$");
        return reg.test(value);
    }
}

//******************************************************************************
// 功能     : 最小数字(不包含边界值)
// 戻る值   : false:不满足；true：满足
// 参数     ：value：验证值 minLength:最小长度    
//******************************************************************************
function min(value, minValue) {
    // 如果为空
    if (isNullOrEmpty(value)) {
        return true;
    }
    return Number(value) > Number(minValue);
}

//******************************************************************************
// 功能     : 最大数字(不包含边界值)
// 戻る值   : false:不满足；true：满足
// 参数     ：value：验证值 param:最大长度       
//******************************************************************************
function max(value, maxValue) {
    // 如果为空
    if (isNullOrEmpty(value)) {
        return true;
    }
    return Number(value) < Number(maxValue);
}

//******************************************************************************
// 功能     : 最小数字(包含边界值)
// 戻る值   : false:不是整数；true：整数
// 参数     ：value：验证值 minLength:最小长度    
//******************************************************************************
function minEquals(value, minValue) {
    // 如果为空
    if (isNullOrEmpty(value)) {
        return true;
    }
    return Number(value) >= Number(minValue);
}

//******************************************************************************
// 功能     : 最大数字(包含边界值)
// 戻る值   : false:不是整数；true：整数
// 参数     ：value：验证值 param:最大长度       
//******************************************************************************
function maxEquals(value, maxValue) {
    // 如果为空
    if (isNullOrEmpty(value)) {
        return true;
    }
    return Number(value) <= Number(maxValue);
}

//******************************************************************************
// 功能     : 获取动态table：键、值
// 戻る值   : 戻るJSON
// 参数     ：tableId:JqGrid的ID       
//******************************************************************************
function getTableDataJson(tableId) {
    var trsOfTable;
    if ($(tableId + " tbody tr").length > 0) {
        trsOfTable = $(tableId + " tbody tr");
    }
    else {
        trsOfTable = $(tableId + " tr");
    }
    var list = [];
    trsOfTable.each(function () {
        //如果不是首行样式
        if (!$(this).hasClass("jqgfirstrow")) {
            var item = {};
            $(this).find('td').find('input,select,textarea,label').each(function () {
                //如果不是行選択控件
                if (!$(this).hasClass("cbox")) {
                    var pk_id = $(this).attr('id');
                    var pk_value;
                    if ($(this).attr('type') == "checkbox") {
                        if ($(this).attr("checked")) {
                            pk_value = true;
                        } else {
                            pk_value = false;
                        }
                    }
                    else if (this.tagName == "LABEL") {
                        pk_value = $(this).text();
                    }
                    else {
                        pk_value = $(this).val();
                    }
                    var array = new Array();
                    array = pk_id.split("➩"); //字符分割
                    item[array[0]] = $.trim(pk_value);
                }
            })
            list.push(item);
        }
    });

    return JSON.stringify(list);
}

//******************************************************************************
// 功能     : 检查列表数据中是否有重复数据
// 戻る值   : 戻るexistFlag(true:有重复数据;false:没有重复数据)以及rowNo(错误的行号)
// 参数     ：data:列表数据;columnNames:数据列名,多列时用;号拼接
//******************************************************************************
function checkListDataExist(data, columnNames) {
    var arr = new Array();
    var columnNameArr = columnNames.split(";");

    for (var i = 0; i < data.length; i++) {
        var keyData = "";
        for (var j = 0; j < columnNameArr.length; j++) {
            keyData = keyData + data[i][columnNameArr[j]];
        }

        if ((jQuery.inArray(keyData, arr)) != -1) {
            return { existFlag: true, rowNo: (i + 1).toString() };
        }
        else {
            arr.push(keyData);
        }
    }
    return { existFlag: false, rowNo: "0" };
}

//******************************************************************************
// 功能     : 获取导出Excel的相关条件
// 戻る值   : 戻る导出Excel的相关条件
// 参数     ：jqGridName:JqGrid名称
//******************************************************************************
function getExcelExportConditon(jqGridName) {
    var data =
    {
        //jqGrid列名
        colIndexs: getJqGridColIndexs(jqGridName),
        page: $("#" + jqGridName).getGridParam('page'),
        sidx: $("#" + jqGridName).getGridParam('sortname'),
        sord: $("#" + jqGridName).getGridParam('sortorder'),
        rows: $("#" + jqGridName).getGridParam('rowNum'),
        defaultSortStr: $("#" + jqGridName).getGridParam('defaultSortStr')
    };
    return data;
}

//******************************************************************************
// 功能     : 戻るJqGrid的列名(用逗号拼接,并且隐藏列前面标记“hidden➩”)
// 戻る值   : 戻るJqGrid的列名(用逗号拼接,并且隐藏列前面标记“hidden➩”)
// 参数     ：jqGridName:JqGrid名称
//******************************************************************************
function getJqGridColIndexs(jqGridName) {
    var colModel = $("#" + jqGridName).getGridParam('colModel');
    var colNames = $("#" + jqGridName).getGridParam('colNames');

    var colIndexs = "";
    $.each(colModel, function (i) {
        if (colModel[i]["name"] == "cb") {
            return true;
        }
        if (colModel[i]["name"] == "Action") {
            return true;
        }
        if (colModel[i]["name"] == "RestTime") {
            return true;
        }
        if (colModel[i]["hidden"]) {
            colIndexs = colIndexs + "hidden➩" + colModel[i]["name"] + "➩" + colNames[i] + "➩" + colModel[i]["excelWidth"] + ",";
        }
        else {
            colIndexs = colIndexs + colModel[i]["name"] + "➩" + colNames[i] + "➩" + colModel[i]["excelWidth"] + ",";
        }
    });
    //去除最后一个逗号
    return colIndexs.substr(0, colIndexs.length - 1);
}

//******************************************************************************
// 功能     : 戻るJqGrid的列名(用逗号拼接,并且隐藏列前面标记“hidden➩”)
// 戻る值   : Ture://添加空白行 FALSE :不添加空白行
// 参数     ：jqGridName:JqGrid名称
//******************************************************************************
function DropItemFirstEmptyCheck(controlId, yakusoku, model) {
    //2021/05/27 権限仕様変更 START
    //if (controlId == "GeneralDepartmentName") {
    //    if (yakusoku == "001") {
    //        return true;
    //    }
    //}
    //else if (controlId == "DepartmentName") {
    //    if (yakusoku == "001" || yakusoku == "002") {
    //        return true;
    //    }
    //}
    //else if (controlId == "ProjectName") {

    //    if (yakusoku == "001" || yakusoku == "002" || yakusoku == "003" || yakusoku == "004" || yakusoku == "005" ) {
    //        return true;
    //    }
    //}
    //ユーザ管理画面
    if (model == 'UserManage') {
        //総経理、部長、担当部長、PM、GL、TL
        if (yakusoku == "001" || yakusoku == "002" || yakusoku == "003" || yakusoku == "004" || yakusoku == "005" || yakusoku == "006") {
            return true;
        }
        return false;
    }
    else {
        if (controlId == "GeneralDepartmentName") {

            //総経理
            if (yakusoku == "001") {
                return true;
            }
        }
        else if (controlId == "DepartmentName") {

            //総経理、部長、担当部長
            if (yakusoku == "001" || yakusoku == "002" || yakusoku == "003") {
                return true;
            }
        }
        else if (controlId == "ProjectName") {

            if (yakusoku == "001" || yakusoku == "002" || yakusoku == "003" || yakusoku == "004" || yakusoku == "005") {
                return true;
            }
        }
    }

    return false;
}

//******************************************************************************
// 功能     : 获取票号的入力规则
// 戻る值   : 票号的入力规则
// 参数     ：sysType:子系统类型;alertType:案件类型;title:件名
//******************************************************************************
function getTicketNoRule(sysType, alertType, title) {
    var checkStr = "";

    //TCCN
    if (sysType == "001") {
        //17、19
        if (alertType == "001") {
            if (title.indexOf("17INFRA") > -1 || title.indexOf("17APP") > -1) {
                checkStr = "TSCC17INC";
            } else if (title.indexOf("TBDC_19INFRA") > -1 || title.indexOf("TBDC_19APP") > -1) {
                checkStr = "TBDC19INC";
            } else if (title.indexOf("ECN_19INFRA") > -1 || title.indexOf("ECN_19APP") > -1) {
                checkStr = "TBDC19INC";
            }
        }
        //19MC
        else if (alertType == "002") {
            if (title.indexOf("TBDC_21INFRA") > -1 || title.indexOf("TBDC_21APP") > -1) {
                checkStr = "TBDC19INC";
            }
        }
        //21MM
        else if (alertType == "003") {
            if (title.indexOf("UPF_21INFRA") > -1 || title.indexOf("UPF_21APP") > -1) {
                checkStr = "MMGP21INC";
            } else if (title.indexOf("APP_21INFRA") > -1 || title.indexOf("APP_21APP") > -1) {
                checkStr = "MMGP21INC";
            } else if (title.indexOf("AGT_21INFRA") > -1 || title.indexOf("AGT_21APP") > -1) {
                checkStr = "MMGP21INC";
            } else if (title.indexOf("NTF_21INFRA") > -1 || title.indexOf("NTF_21APP") > -1 || title.indexOf("KMC_21INFRA") > -1) {
                checkStr = "MMGP21INC";
            } else if (title.indexOf("OTA_21INFRA") > -1 || title.indexOf("OTA_21APP") > -1) {
                checkStr = "OTAINC";
            } else if (title == "ログ蓄積基盤" || title == "データ統合管理基盤") {
                checkStr = "DATALAKE_DEVOPS_CN";
            } else if (title == "制御データ基盤") {
                checkStr = "OSDKINC";
            }
        }
        //19TSCPP
        else if (alertType == "004") {
            if (title.indexOf("19TSCPP_INFRA") > -1 || title.indexOf("19TSCPP_APP") > -1) {
                checkStr = "TSCPP19INC";
            }
        }
    }
    // 7&i
    else if (sysType == "002") {
        //GMS
        if (alertType == "001") {
            checkStr = "^INC[0-9]{9}$";
        }
        // ArioHP
        else if (alertType == "002") {
            checkStr = "^SHIPSCU-[0-9]{1,}$"
        }
        else if (alertType == "005" || alertType == "003") {
            checkStr = "^NOA2-.+"
        }
    }

    return checkStr;
}

function checkTicketNoRule(checkStr, ticketNo) {
    if (ticketNo != "" && checkStr != "") {
        //检查票号是否符合入力规则(checkStr-****)
        var str = ticketNo.split("-");
        if (str.length != 2 || str[0] != checkStr || str[1].length == 0) {
            return false;
        }
    }

    return true;
}

function checkTicketNoRuleForSAI(checkStr, ticketNo) {
    if (ticketNo != "" && checkStr != "") {
        //检查票号是否符合入力规则(checkStr****)
        if (ticketNo.search(checkStr) == -1) {
            return false;
        }
    }

    return true;
}

function handleInfoUnEnabled(targets) {
    var targetArray = targets.split(",");
    for (var i = 0; i < targetArray.length; i++) {
        var target = $("#" + targetArray[i]);
        if (target) {
            target.parent().hide();
        }
    }
}

function handleInfoEnabled(targets) {
    var targetArray = targets.split(",");
    for (var i = 0; i < targetArray.length; i++) {
        var target = $("#" + targetArray[i]);
        if (target) {
            target.parent().show();
        }
    }
}

//******************************************************************************
// 功能     : 数字滚动
//******************************************************************************
const Odometer = (function (win, doc) {
    class OdometerFn {
        constructor(x, y) {
            this.setting = {
                len: null, //默认最小位数
                speed: 1000,//动画速度
                num: "", //初始化值
                symbol: '',//默认的分割符号，千，万，千万
                dot: 0,//保留几位小数点 
                zero: true
            }
            this.$parent = doc.querySelector(x);
            this.html = `<div class="number-animate-dom" data-num="{{num}}">
                        <span class="number-animate-span">0</span>
                        <span class="number-animate-span">1</span>
                        <span class="number-animate-span">2</span>
                        <span class="number-animate-span">3</span>
                        <span class="number-animate-span">4</span>
                        <span class="number-animate-span">5</span>
                        <span class="number-animate-span">6</span>
                        <span class="number-animate-span">7</span>
                        <span class="number-animate-span">8</span>
                        <span class="number-animate-span">9</span>
                        <span class="number-animate-span">0</span>
                        <span class="number-animate-span">.</span>
                      </div>`;
            this.extend(this.setting, y);
            this.init(this.$parent, y)
        }
        init(x, y) {
            x.innerHTML = this.setNumDom(this.numToArr(this.setting.num))
            this.animate(x);
        };
        animate($parent) {//执行动画
            let $dom = $parent.querySelectorAll('.number-animate-dom');
            for (let o of $dom) {
                let num = o.getAttribute('data-num');
                if (this.setting.zero) num = (num == 0 ? 10 : num);
                this._height = o.offsetHeight / 12;
                o.style['transform'] = o.style['-webkit-transform'] = 'translateY(' + (num == "." ? -11 * this._height : -num * this._height) + 'px)';
                o.style['transition'] = o.style['-webkit-transition'] = (num == "." ? 0 : this.setting.speed / 1000) + 's'
            }
        }
        setNumDom(arrStr) {//分割符号
            let shtml = '<div class="number-animate">';
            arrStr.forEach((o, i) => {
                if (i != 0 && (arrStr.length - i) % 3 == 0 && this.setting.symbol != "" && o != ".") {
                    shtml += '<div class="number-animate-dot"><span>' + this.setting.symbol + '</span></div>' + this.html.replace("{{num}}", o);
                } else {
                    shtml += this.html.replace("{{num}}", o);
                }
            });
            shtml += '</div>';
            return shtml;
        }
        update(num) {
            let newArr = this.numToArr(num), $dom = this.$parent.querySelectorAll(".number-animate-dom");
            if ($dom.length != newArr.length) {
                this.$parent.innerHTML = this.setNumDom(this.numToArr(num))
            } else {
                ;[].forEach.call($dom, (o, i) => {
                    o.setAttribute('data-num', newArr[i]);
                });
            }
            this.animate(this.$parent);
        }
        numToArr(num) {
            num = parseFloat(num).toFixed(this.setting.dot);
            let arrStr = typeof (num) == 'number' ? num.toString().split("") : num.split("")
            let arrLen = arrStr.length;
            if (arrStr.length <= this.setting.len) {
                for (let _lens = 0; _lens < this.setting.len - arrLen; _lens++) {
                    arrStr.unshift(0)
                }
            }
            return arrStr;
        }
        extend(n, n1) {
            for (let i in n1) { n[i] = n1[i] };
        }
    }
    return OdometerFn;
})(window, document);

//******************************************************************************
// 功能     : 数字滚动
// 戻る值   : 前后数据是否相同
// 参数     ：id:对象;newData:新数据
//******************************************************************************
function checkOdometer(id, newData) {
    var list = $("#" + id + " .number-animate-dom");
    var strNumber = "";

    if (list.length == 0) {
        return true;
    }

    for (var i = 0; i < list.length; i++) {
        strNumber += $(list[i]).attr('data-num');
    }

    if (parseInt(strNumber) != newData) {
        return true;
    }

    return false;
}

//******************************************************************************
// 功能     : 生成汉字头像
// 戻る值   : 头像
// 参数     ：element:id, str:汉字, color:背景色
//******************************************************************************
function textToImg(element, str, color) {
    if (!str) {
        str = "空";
        color = "#000000";
    }

    var name, fsize;
    name = str;
    fsize = 18;
    var fontSize = 18;
    var fontWeight = "bold";
    var canvas = document.getElementById(element);
    var img1 = document.getElementById(element);
    canvas.width = 36;
    canvas.height = 36;
    var context = canvas.getContext("2d");
    context.fillStyle = getBG(str, color);
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.fillStyle = "#FFF";
    context.font = fontWeight + " " + fsize + "px sans-serif";
    context.textAlign = "center";
    context.textBaseline = "middle";
    context.fillText(name, fontSize, fontSize);
    return canvas.toDataURL("image/png")
}

//获取随机背景色
function getBG(sname, color) {
    if (color) {
        return color;
    }
    var str = "";
    for (var i = 0; i < sname.length; i++) {
        str += parseInt(sname[i].charCodeAt(0), 10).toString(16);
    }
    return '#' + str.slice(1, 4)
};


(function ($, window, document, undefined) { //用一个自调用匿名函数把插架代码包裹起来，防止代码污染
    $.fn.mySelect = function (options) {
        //var defaults = {          //defaults 使我们设置的默认参数。
        //    Event: "click",      //触发响应事件
        //    msg: "Holle word!"   //显示内容
        //};
        //var options = $.extend(defaults, options);    //将传入参数和默认参数合并
        //console.log(options)
        var $this = $(this);      //当然响应事件对象
        // $this.live(options.Event, function (e) {   //功能代码部分，绑定事件
        //     alert(options.msg);
        // });
        //生成option-item并追加展示
        var html = '';
        html += '<div class="select-picker-search">';
        html += '<div class="select-picker-search-checked">すべて</div>';
        html += '</div>';
        html += '<div class="select-picker-options-wrp">';
        html += '<div class="select-picker-options-serch">';
        html += '<input type="text" placeholder="">';
        html += '</div>';
        html += '<div class="select-picker-options-list">';
        $this.find("option").each(function () {
            let _this = $(this);
            html += '<div class="select-picker-options-list-item">';
            html += '<b class="duihao duihao-checked"></b>';
            html += '<span>' + _this.text() + '</span>';
            html += '</div>';
        })
        html += '</div>';
        html += '</div>';
        $this.append(html);
        // 下拉显示隐藏
        $this.on('click', ".select-picker-search", function (e) {   //功能代码部分，绑定事件
            $(this).next('.select-picker-options-wrp').toggle();
            $(this).next('.select-picker-options-wrp').find('.select-picker-options-serch input').focus();
        });

        // 点击选中或不选
        var initFlg = 0;
        $this.on('click', ".select-picker-options-list-item", function () {
            let _this = $(this);
            if ($.trim(_this.text()) != 'すべて') {
                initFlg = 1;
            } else {
                initFlg = 0;
            }

            if (_this.find('.duihao-nocheck').length > 0) {
                _this.find('.duihao').removeClass('duihao-nocheck').addClass('duihao-checked');
            } else {
                _this.find('.duihao').addClass('duihao-nocheck').removeClass('duihao-checked');
            }

            // 点击全选，如果checked，则所有都checked
            if (initFlg == 0 && $(".select-picker-options-list-item span").eq(0).prev().hasClass('duihao-checked')) {
                $this.find(".select-picker-options-list-item").each(function () {
                    $this.find('.duihao').removeClass('duihao-nocheck').addClass('duihao-checked');
                })
            }

            // 点击全选，如果nocheck，所有选项nocheck
            if (initFlg == 0 && !$(".select-picker-options-list-item span").eq(0).prev().hasClass('duihao-checked')) {
                $this.find(".select-picker-options-list-item").each(function () {
                    $this.find('.duihao').addClass('duihao-nocheck').removeClass('duihao-checked');
                })
            }

            // 取消任意选项，则把全选去除
            if ($.trim(_this.text()) != 'すべて' && _this.find('.duihao-nocheck').length > 0) {
                $(".select-picker-options-list-item span").eq(0).prev().addClass('duihao-nocheck').removeClass('duihao-checked');
            }

            // 循环遍历options中选中的项添加到选项栏中
            var checkedArr = [];
            $this.find(".select-picker-options-list-item").each(function () {
                let _this = $(this);
                if (_this.find('.duihao-checked').length > 0) {
                    checkedArr.push($.trim(_this.text()))
                }
            })
            if (checkedArr.length > 0) {
                if (checkedArr.toString().indexOf('すべて') > -1) {
                    $this.find('.select-picker-search-checked').text('すべて').css('color', '#757575');
                } else {
                    $this.find('.select-picker-search-checked').text(checkedArr.join(','));
                }
                // $this.find('.select-picker-search-checked').text(checkedArr.join(',')).css('color', '#fff');
            } else {
                $this.find('.select-picker-search-checked').text('すべて').css('color', '#757575');
            }
        })

        // 前端实现下拉搜索 
        $this.on('keyup', ".select-picker-options-serch input", function () {
            var text = $(this).val();
            var html = '';
            $this.find("option").each(function () {
                let _this = $(this);
                if (_this.text().indexOf(text) != -1) {
                    html += '<div class="select-picker-options-list-item">';
                    html += '<b class="duihao duihao-nocheck"></b>';
                    html += '<span>' + _this.text() + '</span>';
                    html += '</div>';
                }
            })
            if (html == '') {
                html += '<p style="text-align:center;">没有相关内容</p>';
            }
            $this.find(".select-picker-options-list").html('').append(html);
        })
    }
    // 点击document任意地方 下拉消失
    $(document).click(function (event) {
        var _con = $('.select-picker-options-wrp'); // 设置目标区域
        var _con2 = $('.select-picker-search-checked'); // 设置目标区域
        if (!_con2.is(event.target) && !_con.is(event.target) && _con.has(event.target).length === 0) { // Mark 1 
            $('.select-picker-options-wrp').hide(); //淡出消失
        }
    });
})(jQuery, window, document);

function BindColSelectOption(config) {
    var dropList = $("#" + config.controlId);
    if (!config.notClearFlag) {
        //先清空下拉框
        dropList.empty();
    }

    dropList.append($("<option value='all'>すべて</option>"));

    //dropList.find("option[value='all']").

    //获取画面的操作区分
    var strFlag = $("#strFlag").val();

    if (config.data) {
        $.each(config.data, function (i) {
            var status = config.data[i]["Status"];
            //如果不是作废状態
            if (status != "002") {
                dropList.append($("<option></option>").val(config.data[i]["SelectKey"]).html(config.data[i]["SelectValue"]));
            }
            else {
                //编辑模式
                if (strFlag == "E") {
                    dropList.append($("<option disabled='disabled' style='background-color:rgba(242, 242, 242, 1)'></option>").val(config.data[i]["SelectKey"]).html(config.data[i]["SelectValue"]));
                }
                //不是追加模式
                else if (strFlag != "A") {
                    dropList.append($("<option style='background-color:rgba(242, 242, 242, 1)'></option>").val(config.data[i]["SelectKey"]).html(config.data[i]["SelectValue"]));
                }
            }
        });
    }
    if (!isNullOrEmpty(config.defaultVal)) {
        dropList.val(config.defaultVal);
    }
    if (select2Flag) {
        if (config.searchBox) {
            dropList.select2();
        }
        else {
            dropList.select2({
                minimumResultsForSearch: -1
            });
        }
    }

    //去重处理
    var i = 0;
    while (i < dropList[0].length) {
        var j = i + 1;
        while (j < dropList[0].length) {
            if (dropList[0].options[i].text == dropList[0].options[j].text) {
                dropList[0].options[j] = null;
            } else {
                j++;
            }
        }
        i++;
    }

    $('#select2-' + config.controlId).hide();
}

//列显示下拉制御
function showColumn() {
    var colArrStr = $('.select-picker-search-checked').text();
    if (colArrStr != 'すべて') {
        var colArr = colArrStr.split(',');
        allColArr.forEach(function (a, b, c) {
            if (colArr.indexOf(a.SelectValue) > -1) {
                $("#grid-table").setGridParam().showCol(a.SelectKey);
            } else {
                $("#grid-table").setGridParam().hideCol(a.SelectKey);
            }
        })
    } else {
        allColArr.forEach(function (a, b, c) {
            $("#grid-table").setGridParam().showCol(a.SelectKey);
        })
    }
}

// 返回一览列显示下拉制御
function showColumnFromPrev() {
    var showCol = $('#ShowColumn').val();
    var showColArr = [];
    if (showCol) {
        $('.select-picker-search-checked').text(showCol);
        showColArr = showCol.split(',');
        //清除选中
        $(".select-picker-options-list-item").each(function () {
            $(this).find('.duihao').addClass('duihao-nocheck').removeClass('duihao-checked');
        });
        showColArr.forEach(function (a) {
            $(".select-picker-options-list-item").each(function () {
                let _this = $(this).find("span");
                if (a == _this.text()) {
                    $(this).find('.duihao').addClass('duihao-checked').removeClass('duihao-nocheck');
                }
            });
        });
    }
}

//判断文件是否存在
function fileExists(url) {
    var isExists;
    $.ajax({
        url: url,
        async: false,
        type: 'HEAD',
        error: function () {
            isExists = 0;
        },
        success: function () {
            isExists = 1;
        }
    });

    if (isExists == 1) {
        return true;
    } else {
        return false;
    }

}


function getColumnList() {
    var arr = Array.from($("#grid-table").getGridParam().colNames).slice(1);
    var list = [];
    arr.forEach(x => {
        let ColumnSelectDto = {};
        ColumnSelectDto.ColumnName = x.trim();
        list.push(ColumnSelectDto);
    });

    arr = Array.from($("#grid-table").getGridParam().colModel).slice(1);
    for (var i = 0; i < list.length; i++) {
        list[i].ColumnId = arr[i].name;
        if (arr[i].hidden) {
            list[i].Checked = false;
        } else {
            list[i].Checked = true;
        }
    }
    return list;
}

function columnControl(selectArr, unselectArr) {
    selectArr.forEach(x => {
        $("#grid-table").setGridParam().showCol(x);
    })

    unselectArr.forEach(x => {
        $("#grid-table").setGridParam().hideCol(x);
    })
}