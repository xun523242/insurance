﻿lbl_PageName = 列選択
lbl_AlertCondition = 項目
btn_Select = 選択
btn_Back = 戻る