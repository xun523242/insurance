﻿lbl_BusinessType = 業務種別

btn_Search = 検索
btn_Edit = 編集
btn_Delete = 削除
btn_Add = 追加
btn_View = 照会

lbl_SearchCondition = 検索条件
lbl_PageName = 処理失敗一覧
tbl_List = 処理失敗一覧
colName = 'ID', '業務種別', 'メールアドレス', '電話番号', 'ptkey'