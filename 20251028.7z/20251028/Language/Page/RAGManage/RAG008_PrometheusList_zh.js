﻿lbl_Description = Description
lbl_Summary = Summary
lbl_AlertName = AlertName
lbl_Severity = Severity
lbl_Namespace = Namespace

btn_Search = 検索
btn_Edit = 編集
btn_Delete = 削除
btn_Add = 追加
btn_View = 照会
btn_Export = 集計
lbl_SearchCondition = 検索条件
lbl_PageName = RAGメンテナンス一覧（Insv-Prometheus）
tbl_List = メンテナンス一覧
colName = 'ID', 'Type', 'Description', 'Summary', 'AlertName', 'Severity', 'Env', 'Tenant', 'Namespace', 'Instance', 'CreatedByKind', 'CreatedByName', 'HostIp', 'HostNetwork', 'KubernetesNode', 'Node', 'Phase', 'Pod', 'PodIp', 'PriorityClass', 'Uid', 'Deployment', 'Container', 'Cluster', 'Index', 'Daemonset', '対処方法', '手順書', '連絡先①_名前', '連絡先（窓口）_メール', '電話先①', '電話先②'