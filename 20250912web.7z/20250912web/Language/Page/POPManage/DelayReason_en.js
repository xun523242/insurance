﻿lbl_PageName = UnCorrespond Reason
lbl_Reason = Reason
btn_Save = Save
lbl_AlertCondition = Alert Info
lbl_MainReason = Main Reason