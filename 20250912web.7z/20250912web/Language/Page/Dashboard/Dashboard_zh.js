﻿lbl_TitleInfo = AI無人監視ダッシュボード
lbl_AllInfo = 全体案件進捗率
lbl_GMS = 当日
lbl_OnPre = 月間
lbl_DataDog = 四半期間
lbl_NOC = 年間