﻿lbl_PageName_BatchCalenderAdd = Batch Calender Add
lbl_BatchCalenderAdd = Batch Calender Add
lbl_DayTime = Date
lbl_StartTime = From
lbl_EndTime = To
lbl_Plan = Plan
lbl_Remark = Remark
lbl_Status = Status
lbl_ChargeBy = Charge By

btn_Save = Save
btn_Back = Back