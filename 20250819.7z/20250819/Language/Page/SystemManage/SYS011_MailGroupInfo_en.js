﻿lbl_PageName = SYS011_GroupPasswordChange
lbl_OldPassword = Old password
lbl_NewPassword = New password
lbl_ConfirmNewPassword = Confirm new password
btn_Save = Save
btn_Cancel = ReSet
lbl_PasswordInfo = Password revision
