﻿lbl_PageName = 未対応理由説明
lbl_Reason = 理由説明
btn_Save = 保存
lbl_AlertCondition = 未対応理由情報
lbl_MainReason = 未対応理由
