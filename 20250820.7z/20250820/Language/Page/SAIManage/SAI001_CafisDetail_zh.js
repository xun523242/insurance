﻿lbl_AlertId = アラートID
lbl_ReceivingTime = 受信時間
lbl_SystemName = システム名
lbl_AlertTitle = 件名
lbl_Contents = メール内容
lbl_Status = 案件進捗
lbl_ConfirmUser = 確認者
lbl_Remark = 備考

lbl_AIAlertInfo = AI情報分析
lbl_RunGroup = 運用グループ
lbl_HappenTime = 発生日時
lbl_LinkSystem = 関連システム
lbl_Node = ノード
lbl_ObjectName = オブジェクト
lbl_Appli = アプリ
lbl_Message = メッセージ
lbl_ErrorLink = 故障案件URL
lbl_XonopsMethod = 指示文対応

lbl_AIHandleInfo = AI対処情報分析
lbl_MethodStatus = 運用対処有無
lbl_MethodTime = 運用対処期限
lbl_MethodContents = 運用対処内容
lbl_MethodInfos = 引継関連資料

btn_Save = 保存
btn_Back = 戻る
lbl_AIHandleLog = AI処理ログ
lbl_AlertInfo = アラート情報
lbl_PageName = アラート詳細情報
lbl_LogInfo = ログ情報
tbl_List = ログ
colName = '日時', '操作者', 'ログ'