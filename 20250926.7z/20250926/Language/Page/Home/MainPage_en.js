﻿lbl_SystemName = SD System
lbl_ModifyPassword = modify password
lbl_Logout = logout
lbl_MyInfo = Personal Information