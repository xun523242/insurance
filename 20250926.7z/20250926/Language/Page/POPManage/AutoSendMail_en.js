﻿lbl_PageName_AutoSendMail = Auto Send Mail
lbl_AutoSendMail = SendMail
lbl_From = From
lbl_To = To
lbl_CC = CC
lbl_BCC = BCC
lbl_MailName = MailName
lbl_MailContent = MailContent
lbl_AddFile = Add File

btn_Send = Send
btn_Sended = Sended
btn_Back = Back
btn_FirstSend = First Send
btn_RecoveredSend = Recovered Send
btn_CyberArkEPMSend = Send
btn_select = Reference