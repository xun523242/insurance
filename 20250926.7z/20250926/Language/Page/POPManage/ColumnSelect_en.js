﻿lbl_PageName = Column Select
lbl_AlertCondition = Column
btn_Select = Select
btn_Back = Back