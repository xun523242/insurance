﻿lbl_TitleInfo = JI無人監視ダッシュボード
lbl_AllInfo = 全体案件進捗率
lbl_EC2 = EC2
lbl_RDS = RDS
lbl_CloudWatch = AWS CloudWatch
lbl_Notification = AWS Notification