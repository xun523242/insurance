﻿lbl_Name = Name
lbl_AWSAccount = AWSAccount
lbl_AlarmArn = AlarmArn

btn_Search = 検索
btn_Edit = 編集
btn_Delete = 削除
btn_Add = 追加
btn_View = 照会
btn_Export = 集計
lbl_SearchCondition = 検索条件
lbl_PageName = RAGメンテナンス一覧（JI-CloudWatch）
tbl_List = メンテナンス一覧
colName = 'ID', 'Name', 'AWSAccount', 'AlarmArn', '対処方法', '手順書', '連絡先①_名前', '連絡先（窓口）_メール', '電話先①'