﻿lbl_PageName = CalenderDefault List
lbl_Month = Month
btn_Insert = Insert
btn_Import = Excel U/L
lbl_SearchCondition = Search Condition

tbl_List = CalenderDefault List
colName = 'No', 'Type', 'Times', 'Day', 'StartTime', 'EndTime', 'PlanInfo'
