﻿OtherResource_zh = {
    UserId: "ユーザ名",
    Password: "パスワード",
    SelectRow: "選択行",
    RightGroup: "権限グループ"
};

