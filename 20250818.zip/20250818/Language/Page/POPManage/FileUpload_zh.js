﻿lbl_PageName = 文件上传
lbl_file = 文件
btn_upload = 上传
btn_select = 选择
lbl_FileCondition = 文件信息
