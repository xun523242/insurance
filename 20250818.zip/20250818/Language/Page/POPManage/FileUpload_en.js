﻿lbl_PageName = FileUpload
lbl_file = File
btn_upload = Upload
btn_select = Reference
lbl_FileCondition = File info