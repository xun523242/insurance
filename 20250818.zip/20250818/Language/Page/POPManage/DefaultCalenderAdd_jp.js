﻿lbl_PageName_DefaultCalenderAdd = デフォルト新規
lbl_DefaultCalenderAdd = デフォルト新規
lbl_StartHour = 開始時間
lbl_EndHour = 終了時間
lbl_StartTime = 開始日期
lbl_EndTime = 終了日期
lbl_Plan = 計画
lbl_Remark = 備考
lbl_ChargeBy = 担当者
lbl_defType = 日期種別

btn_Save = 保存
btn_Back = 戻る