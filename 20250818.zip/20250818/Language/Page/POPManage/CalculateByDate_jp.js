﻿lbl_PageName_AutoSendMail = 自動送信
lbl_AutoSendMail = 送信
lbl_From = 差出人
lbl_To = 宛先
lbl_CC = CC
lbl_MailName = 件名
lbl_MailContent = メール本文

btn_Send = 送信
btn_Back = 戻る

lbl_PageName_CalculateByDate = 集計
lbl_CalculateByDate = 集計日期選択
lbl_ReceivingTimeFrom = 集計開始日期
lbl_ReceivingTimeTo = 集計終了日期

btn_Cal = 集計
btn_Back = 戻る