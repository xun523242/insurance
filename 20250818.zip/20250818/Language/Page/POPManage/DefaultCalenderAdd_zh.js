﻿lbl_PageName_DefaultCalenderAdd = 默认事件添加
lbl_DefaultCalenderAdd = 默认事件添加
lbl_StartHour = 开始时间
lbl_EndHour = 结束时间
lbl_StartTime = 开始日期
lbl_EndTime = 结束日期
lbl_Plan = 标题
lbl_Remark = 备注
lbl_ChargeBy = 负责人
lbl_defType = 日期类型

btn_Save = 保存
btn_Back = 返回