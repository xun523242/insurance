﻿lbl_PageName_AutoSendMail = 自动发送
lbl_AutoSendMail = 发送
lbl_From = 发送地址
lbl_To = 收件地址
lbl_CC = CC
lbl_BCC = BCC
lbl_MailName = 标题
lbl_MailContent = 内容
lbl_AddFile = 附件上传

btn_Send = 发送
btn_Sended = 已发送
btn_Back = 取消
btn_FirstSend = 第一报
btn_RecoveredSend = 复旧报
btn_CyberArkEPMSend = 已发送
btn_select = 选择