﻿lbl_PageName_BatchCalenderAdd = カレンダー一括新規
lbl_BatchCalenderAdd = 一括新規
lbl_DayTime = 日期
lbl_StartTime = 開始時間
lbl_EndTime = 終了時間
lbl_Plan = 計画
lbl_Remark = 備考
lbl_Status = 状態
lbl_ChargeBy = 担当者

btn_Save = 保存
btn_Back = 戻る