﻿lbl_PageName_BatchCalenderAdd = 日历事件批量添加
lbl_BatchCalenderAdd = 批量添加
lbl_DayTime = 时间
lbl_StartTime = 开始时间
lbl_EndTime = 结束时间
lbl_Plan = 标题
lbl_Remark = 备考
lbl_Status = 状态
lbl_ChargeBy = 负责人

btn_Save = 保存
btn_Back = 返回