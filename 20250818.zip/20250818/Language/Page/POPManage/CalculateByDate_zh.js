﻿lbl_PageName_AutoSendMail = 自动发送邮件
lbl_AutoSendMail = 发送
lbl_From = 发送地址
lbl_To = 收件地址
lbl_CC = CC
lbl_MailName = 标题
lbl_MailContent = 内容

btn_Send = 发送
btn_Back = 返回

lbl_PageName_CalculateByDate = 统计
lbl_CalculateByDate = 日期选择
lbl_ReceivingTimeFrom = 开始日期
lbl_ReceivingTimeTo = 结束日期

btn_Cal = 统计
btn_Back = 返回