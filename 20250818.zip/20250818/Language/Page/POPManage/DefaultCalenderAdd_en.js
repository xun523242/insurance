﻿lbl_PageName_DefaultCalenderAdd = Default Calender Add
lbl_DefaultCalenderAdd = Default Calender Add
lbl_StartHour = Start Hour
lbl_EndHour = End Hour
lbl_StartTime = From
lbl_EndTime = To
lbl_Plan = Plan
lbl_Remark = Remark
lbl_ChargeBy = Charge By
lbl_defType = Default Type

btn_Save = Save
btn_Back = Back