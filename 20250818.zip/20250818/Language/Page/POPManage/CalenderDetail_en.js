﻿lbl_PageName_CalenderDetail = Calender Detail
lbl_CalenderDetail = CalenderDetail
lbl_StartTime = From
lbl_EndTime = To
lbl_Importance = Background-Color
lbl_Plan = Plan
lbl_Remark = Remark
lbl_Status = Status
lbl_ChargeBy = ChargeBy

btn_Save = Save
btn_Back = Back
btn_Delete = Delete