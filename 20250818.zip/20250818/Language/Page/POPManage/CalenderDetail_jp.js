﻿lbl_PageName_CalenderDetail = カレンダー詳細画面
lbl_CalenderDetail = カレンダー詳細
lbl_StartTime = 開始日期
lbl_EndTime = 終了日期
lbl_Importance = 背景色
lbl_Plan = 計画
lbl_Remark = 備考
lbl_Status = 状態
lbl_ChargeBy = 担当者

btn_Save = 保存
btn_Back = 戻る
btn_Delete = 削除