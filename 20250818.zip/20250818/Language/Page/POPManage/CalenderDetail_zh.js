﻿lbl_PageName_CalenderDetail = 日历详细画面
lbl_CalenderDetail = 日历详细
lbl_StartTime = 开始时间
lbl_EndTime = 结束时间
lbl_Importance = 背景色
lbl_Plan = 标题
lbl_Remark = 备注
lbl_Status = 状态
lbl_ChargeBy = 负责人

btn_Save = 保存
btn_Back = 返回
btn_Delete = 删除