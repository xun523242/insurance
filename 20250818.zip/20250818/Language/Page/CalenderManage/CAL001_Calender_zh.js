﻿lbl_PageName = 日历一览
btn_Refresh = 刷新
btn_BatchAdd = 批量添加
btn_DefaultAdd = 默认时间添加
lbl_Undo = 未对应
lbl_Doing = 对应中
lbl_Done = 已对应