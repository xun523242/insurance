﻿lbl_PageName = Calender List
btn_Refresh = Refresh
btn_BatchAdd = Batch Add
btn_DefaultAdd = Default Add
lbl_Undo = Undo
lbl_Doing = Doing
lbl_Done = Done