﻿lbl_PageName = カレンダー自動追加
lbl_Month = 日付
btn_Insert = 追加
btn_Import = Excel U / L
lbl_SearchCondition = 日付選択

tbl_List = カレンダーデフォルト事件一覧
colName = 'No', '業務', '頻度', '実施曜日', '開始時間（JST）', '終了時間（JST）', '実施内容'