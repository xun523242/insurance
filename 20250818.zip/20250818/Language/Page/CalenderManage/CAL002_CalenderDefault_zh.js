﻿lbl_PageName = 日历事件添加
lbl_Month = 时间
btn_Insert = 添加
btn_Import = 上传
lbl_SearchCondition = 日期选择

tbl_List = 日历事件一览
colName = 'No', '业务', '频度', '事件日期', '开始时间（JST）', '结束时间（JST）', '内容'