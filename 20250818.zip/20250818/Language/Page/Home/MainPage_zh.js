﻿lbl_SystemName = SD系统
lbl_ModifyPassword = 修改密码
lbl_Logout = 退出
lbl_MyInfo = 头像