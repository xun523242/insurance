﻿lbl_SystemName = SD システム
lbl_ModifyPassword = パスワードの変更
lbl_Logout = 退出
lbl_MyInfo = アバター