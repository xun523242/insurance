﻿lbl_PageName = SYS002_PassWordModify
lbl_UserId = User ID
lbl_OldPassword = Old password
lbl_NewPassword = New password
lbl_ConfirmNewPassword = Confirm new password
btn_Save = Save
btn_Cancel = ReSet
lbl_PasswordInfo = Password revision
