﻿lbl_PageName = SYS002_パスワードの変更
lbl_UserId = ユーザid
lbl_OldPassword = 旧パスワード
lbl_NewPassword = 新しいパスワード
lbl_ConfirmNewPassword = 新しいのパスワードを確認
btn_Save = 保存
btn_Cancel = リセット
lbl_PasswordInfo = パスワードを変更
