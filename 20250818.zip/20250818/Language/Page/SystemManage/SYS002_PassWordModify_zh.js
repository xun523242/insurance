﻿lbl_PageName = 密码修改
lbl_UserId = 用户ID
lbl_OldPassword = 旧密码
lbl_NewPassword = 新密码
lbl_ConfirmNewPassword = 新密码确认
btn_Save = 保存
btn_Cancel = 取消
lbl_PasswordInfo = 修改密码
