﻿OtherResource_zh = {
    UserId: "用户名",
    Password: "密码",
    SelectRow: "选择行",
    RightGroup: "权限组"
};

