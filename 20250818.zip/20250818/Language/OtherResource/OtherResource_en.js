﻿OtherResource_en = {
    UserId: "UserId",
    Password: "Password",
    SelectRow: "SelectRow",
    RightGroup: "RightGroup"
};