﻿lbl_AlertInfo = 案件情報
lbl_Name = Name
lbl_AWSAccount = AWSAccount
lbl_AlarmArn = AlarmArn

lbl_MsgInfo = 対処情報
lbl_ProcessFunction = 対処方法
lbl_ProcessHandbook = 手順書
lbl_ContactName = 連絡先①_名前
lbl_ContactEmailAddress = 連絡先①_メール
lbl_TelNameOne = 電話先①
lbl_TelNameTwo = 電話先②

btn_Save = 保存
btn_Back = 戻る
lbl_PageName = RAGメンテナンス詳細（Insv-CloudWatch）