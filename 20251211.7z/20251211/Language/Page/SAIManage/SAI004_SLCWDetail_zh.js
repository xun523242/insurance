﻿lbl_PageName = アラート詳細情報（SL-CloudWatch）

lbl_AlertInfo = アラート情報
lbl_AlertId = アラートID
lbl_ReceivingTime = 受信時間
lbl_Status = AI処理結果
lbl_Title = 件名
lbl_MailContents = 本文
lbl_CaseStatus = 案件進捗
lbl_ChargeBy = 確認者

lbl_MsgInfo = 対処情報
lbl_CountermeasureMethod = 対処方法
lbl_ProcedureManual = 手順書
lbl_ContactName = 連絡先_名前
lbl_EmailAddress = 連絡先（窓口）_メール
lbl_Phone1 = 電話先①
lbl_Phone2 = 電話先②

lbl_LogInfo = ログ情報
tbl_List = ログ
colName = '日時', '操作者', 'ログ'

btn_Save = 保存
btn_Back = 戻る
btn_BackLog = BackLog起票
btn_BackLogLink = BackLog連携