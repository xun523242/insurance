﻿lbl_PageName_CalculateByDate = CalculateByDate
lbl_CalculateByDate = CalculateByDate
lbl_ReceivingTimeFrom = From
lbl_ReceivingTimeTo = To
lbl_Status = Status
lbl_ChargeBy = ChargeBy

btn_Cal = Calculate
btn_Back = Back