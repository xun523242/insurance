﻿lbl_TitleInfo = INSV無人監視ダッシュボード
lbl_AllInfo = 全体案件進捗率
lbl_Prometheus = Prometheus
lbl_Zabbix = Zabbix
lbl_Notification = AWS Notification
lbl_CloudWatch = AWS CloudWatch